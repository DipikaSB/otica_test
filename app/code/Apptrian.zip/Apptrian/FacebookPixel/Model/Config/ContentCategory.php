<?php
/**
 * @category  Apptrian
 * @package   Apptrian_FacebookPixel
 * @author    Apptrian
 * @copyright Copyright (c) Apptrian (http://www.apptrian.com)
 * @license   http://www.apptrian.com/license Proprietary Software License EULA
 */

namespace Apptrian\FacebookPixel\Model\Config;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;

class ContentCategory extends Value
{
    /**
     * @return $this
     * @throws LocalizedException
     */
    public function beforeSave()
    {
        $value = $this->getValue();

        $pattern = "/^[\p{L}\p{N}_,;:!&#+\*\$?\|'.\-]*$/iu";

        if (!preg_match($pattern, $value)) {
            throw new LocalizedException(
                __('The content_category attribute code is not valid.')
            );
        }

        return parent::beforeSave();
    }
}
