<?php
/**
 * @category  Apptrian
 * @package   Apptrian_FacebookPixel
 * @author    Apptrian
 * @copyright Copyright (c) Apptrian
 * @license   Proprietary Software License EULA
 */

namespace Apptrian\FacebookPixel\Model\Config;

use Magento\Framework\Exception\LocalizedException;
use Laminas\Validator\Regex;

class ParamName extends \Magento\Framework\App\Config\Value
{
    /**
     * @return $this
     * @throws LocalizedException
     */
    public function beforeSave()
    {
        $value = $this->getValue();

        $validator = new Regex([
            'pattern' => '/^[\p{L}\p{N}_,;:!&#\+\*\$\?\|\'\.\-]*$/iu'
        ]);

        if (!$validator->isValid($value)) {
            $message = __(
                'The parameter name is not valid.'
            );

            throw new LocalizedException($message);
        }

        return parent::beforeSave();
    }
}
