<?php
/**
 * @category  Apptrian
 * @package   Apptrian_FacebookPixel
 * @author    Apptrian
 * @copyright Copyright (c) Apptrian
 * @license   Proprietary Software License EULA
 */

namespace Apptrian\FacebookPixel\Model\Config;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;
use Laminas\Validator\Regex;

class PixelId extends Value
{
    /**
     * @return $this
     * @throws LocalizedException
     */
    public function beforeSave()
    {
        $value = $this->getValue();

        $validator = new Regex([
            'pattern' => '/^[0-9,]+$/'
        ]);

        if (!$validator->isValid($value)) {
            $message = __('Please correct Facebook Pixel ID: "%1".', $value);
            throw new LocalizedException($message);
        }

        return parent::beforeSave();
    }
}