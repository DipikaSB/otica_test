<?php
namespace SEO\Schema\Block;

use Magento\Framework\View\Element\Template;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Image as ImageHelper;
use Magento\Review\Model\ReviewFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Catalog\Helper\Output as CatalogOutputHelper;
use Magento\Directory\Model\Currency;
use Magento\Eav\Model\Config;
use Magento\Catalog\Model\Product;

class Schema extends Template
{
    protected $_productRepository;
    protected $imageHelper;
    protected $reviewFactory;
    protected $outputHelper;
    protected $_currency;
    protected $eavConfig;

    public function __construct(
        Template\Context $context,
        ProductRepositoryInterface $productRepository,
        ImageHelper $imageHelper,
        ReviewFactory $reviewFactory,
        CatalogOutputHelper $outputHelper,
        Currency $currency,
        Config $eavConfig,
        array $data = []
    ) {
        $this->_productRepository = $productRepository;
        $this->imageHelper = $imageHelper;
        $this->reviewFactory = $reviewFactory;
        $this->outputHelper = $outputHelper;
        $this->_currency = $currency;
        $this->eavConfig = $eavConfig;
        parent::__construct($context, $data);
    }

    /**
     * Get current product
     */
    public function getProduct()
    {
        try {
            $productId = (int)$this->getRequest()->getParam('id');
            if (!$productId) {
                return null;
            }
            return $this->_productRepository->getById($productId);
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * Product image
     */
    public function getImage($product)
    {
        if (!$product) {
            return '';
        }

        return $this->imageHelper
            ->init($product, 'product_page_image_large')
            ->getUrl();
    }

    /**
     * Main schema output
     */
    public function getSchema()
    {
        $product = $this->getProduct();
        if (!$product) {
            return null;
        }

        $cleanDescription = trim(
            preg_replace(
                '/\s+/',
                ' ',
                strip_tags((string)$description)
            )
        );

        $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
        );

        /**
         * Final schema
         */
        return [
            "@context" => "https://schema.org/",
            "@type" => "Product",
            "name" => (string)$product->getName(),
            "sku" => (string)$product->getSku(),
            "description" => $cleanDescription,
            "image" => $this->getImage($product),
            "brand" => [
                "@type" => "Brand",
                "name" => "Otica Mart"
            ],
            "offers" => [
                "@type" => "Offer",
                "url" => $product->getProductUrl(),
                "priceCurrency" => $this->_storeManager->getStore()->getCurrentCurrencyCode(),
                "price" => (float)$product->getFinalPrice(),
                "availability" => "https://schema.org/InStock",
                "itemCondition" => "https://schema.org/NewCondition",
                "seller" => [
                    "@type" => "Organization",
                    "name" => "Otica Mart",
                    "url" => "https://samsjewelers.com/",
                    "logo" => $mediaUrl . 'schema/logo_sams.svg'
                ]
            ]
        ];
    }
}