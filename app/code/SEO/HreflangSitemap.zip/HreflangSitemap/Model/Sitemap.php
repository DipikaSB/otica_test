<?php

/**
 * SetBlue
 *
 * Copyright (C) 2026 SetBlue <info@setblue.com>
 *
 * @category  SetBlue
 * @package   SEO_HreflangSitemap
 * @copyright Copyright (c) 2026 SetBlue (https://setblue.com/)
 * @license   http://opensource.org/licenses/gpl-3.0.html GNU General Public License, version 3 (GPL-3.0)
 * @author    SetBlue <info@setblue.com>
 */

namespace SEO\HreflangSitemap\Model;

use DOMDocument;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Escaper;
use Magento\Framework\Filesystem;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Sitemap\Helper\Data as SitemapData;
use Magento\Sitemap\Model\ResourceModel\Catalog\CategoryFactory;
use Magento\Sitemap\Model\ResourceModel\Catalog\ProductFactory;
use Magento\Sitemap\Model\ResourceModel\Cms\PageFactory;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Stdlib\DateTime\DateTime as ModelDate;

class Sitemap extends \Magento\Sitemap\Model\Sitemap
{
    protected $scopeConfig;

    public function __construct(
        Context $context,
        Registry $registry,
        Escaper $escaper,
        SitemapData $sitemapData,
        Filesystem $filesystem,
        CategoryFactory $categoryFactory,
        ProductFactory $productFactory,
        PageFactory $cmsFactory,
        ModelDate $modelDate,
        StoreManagerInterface $storeManager,
        RequestInterface $request,
        DateTime $dateTime,
        ScopeConfigInterface $scopeConfig,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;

        parent::__construct(
            $context,
            $registry,
            $escaper,
            $sitemapData,
            $filesystem,
            $categoryFactory,
            $productFactory,
            $cmsFactory,
            $modelDate,
            $storeManager,
            $request,
            $dateTime,
            $resource,
            $resourceCollection,
            $data
        );
    }

    protected function _initSitemapItems()
    {
        $isEnabled = $this->scopeConfig->getValue(
            'sitemap/hreflangsitemap/enabled',
            ScopeInterface::SCOPE_STORE
        );

        $sitemapItems = $this->itemProvider->getItems($this->getStoreId());
        $mappedItems = $this->_mapToSitemapItem();
        $this->_sitemapItems = array_merge($sitemapItems, $mappedItems);

        if ($isEnabled) {
            $this->_tags = [
                self::TYPE_INDEX => [
                    self::OPEN_TAG_KEY =>
                        '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL .
                        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" ' .
                        'xmlns:xhtml="https://www.w3.org/1999/xhtml">' . PHP_EOL,
                    self::CLOSE_TAG_KEY => '</sitemapindex>',
                ],
                self::TYPE_URL => [
                    self::OPEN_TAG_KEY =>
                        '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL .
                        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" ' .
                        'xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" ' .
                        'xmlns:xhtml="https://www.w3.org/1999/xhtml">' . PHP_EOL,
                    self::CLOSE_TAG_KEY => '</urlset>',
                ],
            ];
        } else {
            $this->_tags = [
                self::TYPE_INDEX => [
                    self::OPEN_TAG_KEY =>
                        '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL .
                        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' .
                        PHP_EOL,
                    self::CLOSE_TAG_KEY => '</sitemapindex>',
                ],
                self::TYPE_URL => [
                    self::OPEN_TAG_KEY =>
                        '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL .
                        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" ' .
                        'xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' .
                        PHP_EOL,
                    self::CLOSE_TAG_KEY => '</urlset>',
                ],
            ];
        }
    }

    protected function _getSitemapRow(
        $url,
        $lastmod = null,
        $changefreq = null,
        $priority = null,
        $images = null
    ) {
        $isEnabled = $this->scopeConfig->getValue(
            'sitemap/hreflangsitemap/enabled',
            ScopeInterface::SCOPE_STORE
        );

        $url = $this->_getUrl($url);
        $row = '<loc>' . $this->_escaper->escapeUrl($url) . '</loc>';

        if ($lastmod) {
            $row .= '<lastmod>' .
                $this->_getFormattedLastmodDate($lastmod) .
                '</lastmod>';
        }

        if ($isEnabled) {
            foreach ($this->_storeManager->getStores() as $store) {
                if (!$store->isActive()) {
                    continue;
                }

                $hreflang = $this->_getHrefLangFromStoreCode($store->getCode());
                $storeUrl = rtrim($store->getBaseUrl(), '/');

                $row .= sprintf(
                    '<xhtml:link rel="alternate" hreflang="%s" href="%s"/>',
                    $hreflang,
                    $this->_escaper->escapeUrl($storeUrl)
                );
            }
        }

        return '<url>' . $row . '</url>';
    }

    protected function _getHrefLangFromStoreCode(string $code): string
    {
        if ($code === 'base') {
            return 'x-default';
        }

        return 'en';
    }

    protected function _mapToSitemapItem(): array
    {
        $items = [];

        foreach ($this->_sitemapItems as $data) {
            foreach ($data->getCollection() as $item) {
                $items[] = $this->sitemapItemFactory->create(
                    [
                        'url' => $item->getUrl(),
                        'updatedAt' => $item->getUpdatedAt(),
                        'images' => $item->getImages(),
                        'priority' => $data->getPriority(),
                        'changeFrequency' => $data->getChangeFrequency(),
                    ]
                );
            }
        }

        return $items;
    }

    protected function _escapeXmlText(string $text): string
    {
        $doc = new DOMDocument('1.0', 'UTF-8');
        $fragment = $doc->createDocumentFragment();
        $fragment->appendChild($doc->createTextNode($text));

        return $doc->saveXML($fragment);
    }
}
