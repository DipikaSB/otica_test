<?php

namespace Setblue\UrlReWritesImportExport\Ui\Component\Listing\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

class ImportActions extends Column
{
    const URL_REWRITE_PATH_EDIT = 'setblue_urlrewritesimportexport/import/edit';
    const URL_REWRITE_PATH_DELETE = 'setblue_urlrewritesimportexport/import/delete';

    protected $urlBuilder;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['feed_id'])) {
                    $item[$this->getData('name')] = [
                        'edit' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URL_REWRITE_PATH_EDIT,
                                [
                                    'feed_id' => $item['feed_id']
                                ]
                            ),
                            'label' => __('Edit')
                        ],
                        'delete' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URL_REWRITE_PATH_DELETE,
                                [
                                    'feed_id' => $item['feed_id']
                                ]
                            ),
                            'label' => __('Delete'),
                            'confirm' => [
                                'title' => __('Delete'),
                                'message' => __('Are you sure you wan\'t to delete a profile '. $item['feed_id'] .' record?')
                            ]
                        ]
                    ];
                }
            }
        }

        return $dataSource;
    }
}
