<?php

namespace Setblue\UrlReWritesImportExport\Ui\Component\Listing\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

class PostActions extends Column
{
    const URLREWRITESEXPORT_URL_PATH_EDIT = 'setblue_urlrewritesimportexport/post/edit';
    const URLREWRITESEXPORT_URL_PATH_DELETE = 'setblue_urlrewritesimportexport/post/delete';
    const URLREWRITESEXPORT_URL_PATH_GENERATEFILEFROMGRID = 'setblue_urlrewritesimportexport/post/generatefilefromgrid';
    /**
     * url Builder
     *
     * @var Magento\Framework\UrlInterface
     */
    protected $urlBuilder;
    /**
     * @param Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory  $uiComponentFactory
     * @param \Magento\Framework\UrlInterface  $urlBuilder
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }//end __construct()

    /**
     * @return void
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['export_id'])) {
                    $item[$this->getData('name')] = [
                        'edit' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URLREWRITESEXPORT_URL_PATH_EDIT,
                                [
                                    'export_id' => $item['export_id']
                                ]
                            ),
                            'label' => __('Edit')
                        ],
                        'delete' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URLREWRITESEXPORT_URL_PATH_DELETE,
                                [
                                    'export_id' => $item['export_id']
                                ]
                            ),
                            'label' => __('Delete'),
                            'confirm' => [
                                'title' => __('Delete'),
                                'message' => __('Are you sure you wan\'t to delete a profile '. $item['export_id'].' record?')
                            ]
                        ],
                        'generate' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URLREWRITESEXPORT_URL_PATH_GENERATEFILEFROMGRID,
                                [
                                    'export_id' => $item['export_id']
                                ]
                            ),
                            'label' => __('generate'),
                            'confirm' => [
                                'title' => __('Generate'),
                                'message' => __('Are you sure you wan\'t to generate a file for profile '. $item['export_id'].'?')
                            ]
                        ]
                    ];
                }
            }
        }
        return $dataSource;
    }//end prepareDataSource()
}//end CLASS()