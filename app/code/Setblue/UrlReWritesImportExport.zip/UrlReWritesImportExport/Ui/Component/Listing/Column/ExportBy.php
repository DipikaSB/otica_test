<?php

namespace Setblue\UrlReWritesImportExport\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class ExportBy extends Column
{
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                if ($items['export_by'] == 0) {
                    $items['export_by'] = 'All';
                }if ($items['export_by'] == 1) {
                    $items['export_by'] = 'Entity Type';
                }if ($items['export_by'] == 2) {
                    $items['export_by'] = 'Store View';
                }if ($items['export_by'] == 3) {
                    $items['export_by'] = 'Redirect Type';
                }
            }
        }
        return $dataSource;
    }
}
