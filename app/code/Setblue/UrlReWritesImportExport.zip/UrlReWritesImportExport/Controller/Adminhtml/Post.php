<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml;

abstract class Post extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry = null;
    /**
     * File Factory
     *
     * @var  \Magento\Framework\App\Response\Http\FileFactory
     */
    protected $fileFactory;
    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;
    /**
     * Date Filter
     *
     * @var  \Magento\Framework\Stdlib\DateTime\Filter\Date
     */
    protected $dateFilter;
    /**
     * rule Factory
     *
     * @var   \Setblue\UrlReWritesImportExport\Model\PostFactory
     */
    protected $ruleFactory;
    /**
     * logger
     *
     * @var  \Psr\Log\LoggerInterface
     */
    protected $logger;
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter
     * @param \Setblue\UrlReWritesImportExport\Model\PostFactory $postFactory
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
        \Setblue\UrlReWritesImportExport\Model\PostFactory $postFactory,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Psr\Log\LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->fileFactory = $fileFactory;
        $this->dateFilter = $dateFilter;
        $this->ruleFactory = $postFactory;
        $this->resultLayoutFactory = $resultLayoutFactory;
        $this->logger = $logger;
    }//end __construct()

     /**
      * Initialization Rule
      *
      * @return object
      */
    protected function _initRule()
    {
        $rule = $this->ruleFactory->create();
        $this->coreRegistry->register(
            'setblue_urlrewritesimportexport_data',
            $rule
        );
        $id = (int)$this->getRequest()->getParam('id');

        if (!$id && $this->getRequest()->getParam('export_id')) {
            $id = (int)$this->getRequest()->getParam('export_id');
        }

        if ($id) {
            $this->coreRegistry->registry('setblue_urlrewritesimportexport_data')->load($id);
        }
    }//end _initRule()

     /**
      * Initialization Action
      *
      * @return object
      */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu('Setblue_UrlReWritesImportExport::setblue_urlrewritesimportexport')
            ->_addBreadcrumb(__('Example Rules'), __('Example Rules'));
        return $this;
    }//end _initAction()

     /**
      * permission method in admin controller
      *
      * @return bolean
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Setblue_UrlReWritesImportExport::urlrewrites_export');
    }
}
