<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Setblue\UrlReWritesImportExport\Model\ResourceModel\Import\CollectionFactory;
/**
 * Delete rows from Grid
 *
 * @api
 * @since 100.0.2
 */
class MassDelete extends \Magento\Backend\App\Action
{
     /**
      * filter
      *
      * @var  Magento\Ui\Component\MassAction\Filter
      */
    protected $filter;
     /**
      * collectionFactory
      *
      * @var  Setblue\UrlReWritesImportExport\Model\ResourceModel\Import\CollectionFactory
      */
    protected $collectionFactory;
     /**
      * _coreResource
      *
      * @var \Magento\Framework\App\ResourceConnection
      */
    protected $_coreResource;
     /**
      * _file
      *
      * @var  \Magento\Framework\Filesystem\Driver\File
      */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        \Magento\Framework\App\ResourceConnection $coreResource
    ) {
        $this->filter = $filter;
        $this->_coreResource = $coreResource;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $collectionSize = $collection->getSize();
        foreach ($collection as $item) {
            $this->deleteData($item->getId());
        }

        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $collectionSize));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }

    public function deleteData($id)
    {
        $writeconnection = $this->_coreResource->getConnection('core_write');
        $readconnection = $this->_coreResource->getConnection('core_read');
        $importtable = $this->_coreResource->getTableName('setblue_urlrewritesimportexport_import');
      // deleting data from customer group table before insertion
            $selectdatasql2 = 'select * from ' . $importtable . ' where (feed_id = ' . $id . ')';
            $result4 = $readconnection->fetchAll($selectdatasql2);
        if (sizeof($result4) > 0) {
            $deletesql1 = 'delete from ' . $importtable . ' where (feed_id = ' . $id . ')';
            $result3 = $writeconnection->query($deletesql1);
        }
    }
}
