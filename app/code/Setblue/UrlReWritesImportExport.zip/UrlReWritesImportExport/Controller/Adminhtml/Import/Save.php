<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use \Magento\Framework\Exception\NotFoundException;
use Magento\Backend\Model\Session;

class Save extends \Magento\Backend\App\Action
{
    protected $_fileUploaderFactory;
    protected $messageManager;
    protected $authSession;
    protected $_ifac;
    protected $_bsess;
     /**
      * @param\Magento\Backend\App\Action\Context $context
      * @param \Magento\Framework\View\Result\PageFactory $_messageManagerq
      */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Setblue\UrlReWritesImportExport\Model\ImportFactory $ifac,
        Session $bsess
        ) {
        parent::__construct($context);
        $this->messageManager = $messageManager;
        $this->authSession = $authSession;
        $this->_ifac = $ifac;
        $this->_bsess = $bsess;
        $this->_fileUploaderFactory = $fileUploaderFactory;
    }
    /**
     * Save design action.
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
  /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        $total_UrlReWrites = 0;
        if ($data) {
            $id = $this->getRequest()->getParam('feed_id');
            if (empty($data['feed_id'])) {
                $data['feed_id'] = null;
            }
            if (!empty($data['fileinfo'])) {
                   $fileinfo = json_decode($data['fileinfo'], true);
                   $data['file'] = $fileinfo['filename'];
                   $data['file_data'] = $fileinfo['fileHeading'];
                   $total_UrlReWrites = $fileinfo['totalurlrewritess'];
            }
            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_ifac->create()->load($id);
            if (!$model->getFeedId() && $id) {
                $this->messageManager->addError(__('This Profile no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            $admin = $this->authSession->getUser();
            $data['admin_name'] = $admin->getData('username');
            $model->setData($data);
            try {
                $model->save();
                $this->messageManager->addSuccess(__('Profile saved successfully.'));
                $this->_bsess->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['feed_id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the profile.'));
            }
            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['feed_id' => $this->getRequest()->getParam('feed_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
