<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Framework\Registry;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\LayoutFactory;
use Setblue\UrlReWritesImportExport\Model\ImportFactory;

class Blocks extends Action
{
    /**
     * @var LayoutFactory
     */
    protected LayoutFactory $_resultLayoutFactory;

    /**
     * @var ImportFactory
     */
    protected ImportFactory $_ifac;

    /**
     * @var Registry
     */
    protected Registry $_registry;

    public function __construct(
        Action\Context $context,
        ImportFactory $ifac,
        LayoutFactory $layoutFactory,
        Registry $registry
    ) {
        parent::__construct($context);
        $this->_resultLayoutFactory = $layoutFactory;
        $this->_ifac = $ifac;
        $this->_registry = $registry;
    }

    /**
     * Default urlrewrites export grid page
     *
     * @return \Magento\Framework\View\Result\Layout
     */
    public function execute()
    {
        $resultLayout = $this->_resultLayoutFactory->create();
        $this->_initRuleBlocks();

        $block = $resultLayout->getLayout()
            ->getBlock('setblue_urlrewritesimportexport.import.edit.tab.blocks');

        if ($block) {
            $block->setRelatedBlocks(
                $this->getRequest()->getPost('related_blocks', null)
            );
        }

        return $resultLayout;
    }

    /**
     * Initialization Rule
     *
     * @return \Setblue\UrlReWritesImportExport\Model\Import
     */
    protected function _initRuleBlocks()
    {
        $rule = $this->_ifac->create();
        $ruleId = (int) $this->getRequest()->getParam('feed_id');

        if ($ruleId) {
            $rule->load($ruleId);
        }

        $this->_registry->register(
            'current_urlrewritesimportexport_blocks_import',
            $rule
        );

        return $rule;
    }
}
