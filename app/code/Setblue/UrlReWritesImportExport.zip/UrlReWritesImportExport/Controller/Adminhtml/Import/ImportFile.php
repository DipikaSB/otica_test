<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Framework\Json\Helper\Data as JsonHelper;
use \Magento\Framework\Stdlib\DateTime;
use Magento\Backend\Model\Session;
/**
 * import urlrewrites  file
 *
 * @api
 * @since 100.0.2
 */
class ImportFile extends \Magento\Backend\App\Action
{
     /**
     * Session to save data
     *
     * @var  \Magento\Framework\Session\SessionManagerInterface
     */

    protected \Magento\Framework\Session\SessionManagerInterface $_coreSession;
    protected \Magento\Store\Model\StoreManagerInterface $_storeManager;
    protected \Magento\Framework\Filesystem\Driver\File $_fileDriver;

    protected \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory;
    protected \Magento\Framework\Stdlib\DateTime\TimezoneInterface $_date;
    protected \Magento\Backend\Model\Auth\Session $authSession;
    protected \Setblue\UrlReWritesImportExport\Helper\Data $helperData;
    protected \Magento\Framework\App\Filesystem\DirectoryList $directoryList;
    protected \Setblue\UrlReWritesImportExport\Model\ResourceModel\Import $query;
    protected \Setblue\UrlReWritesImportExport\Model\ImportFactory $_ifac;
    protected \Setblue\UrlReWritesImportExport\Model\ImportTabGridFactory $_tgFac;
    protected \Magento\Backend\Model\Session $_bsess;
    /**
     * Store Manager
     *
     * @var  \Magento\Store\Model\StoreManagerInterface
     */

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Filesystem\Driver\File $fileDriver, 
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Setblue\UrlReWritesImportExport\Helper\Data $helperData,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Setblue\UrlReWritesImportExport\Model\ResourceModel\Import $query,
        \Setblue\UrlReWritesImportExport\Model\ImportFactory $ifac, 
        \Setblue\UrlReWritesImportExport\Model\ImportTabGridFactory $tgFac,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        Session $bsess
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_coreSession = $coreSession;
        $this->authSession = $authSession;
        $this->_date =  $date;
        $this->_fileDriver = $fileDriver;
        $this->_ifac = $ifac;
        $this->_tgFac = $tgFac;
        $this->_bsess = $bsess;
        $this->query = $query;
        $this->helperData = $helperData;
        $this->directoryList = $directoryList;
        $this->_storeManager = $storeManager;
    }
     /**
      * permission method in admin controller
      *
      * @return true
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Setblue_UrlReWritesImportExport::urlrewrites_import');
    }//end _isAllowed()
     /**
      * Main function to import csv/xml file
      *
      * @return response
      */
    public function execute()
    {
        $_postData = $this->getRequest()->getPost();
        $resultJson = $this->resultJsonFactory->create();
        $fileHeading=[];
        $importMode = $_postData['import_behavior'];
        $index = $_postData['index'];

        if ($_postData['index'] == 1) {
            $this->_coreSession->start();
            $this->_coreSession->setFiledata0($_postData['file_data0']);
            if (!empty($this->_coreSession->getMyData())) {
                $myData = $this->_coreSession->getMyData();
                if ($_postData['feed_id']!= $myData['feed_id']) {
                    $this->_coreSession->unsMyData();
                }
            }
// for upload file without press upload button. 
            if (empty($this->_coreSession->getMyData())) {
                 $fileinfo = json_decode($_postData['fileinfo'], true);
                 $newFileName = $fileinfo['filename'];
                 $_fileType = substr($newFileName, -3);
                 $_mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                  if ($this->_fileDriver->isExists($this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA). '/urlrewritesimport/default/icon-csv.png')) {
                    $_iconArray = [
                    'csv' => $_mediaUrl.'urlrewritesimport/default/icon-csv.png',
                    ];
                }
                  if (isset($_iconArray[$_fileType])) {
                      $_src = $_iconArray[$_fileType];
                    } else {
                        $_src = $_mediaUrl.'urlrewritesimport/'.$newFileName;
                    }
                    $html = '<div class="image item base-image" data-role="image" id="'. uniqid().'">
                            <div class="product-image-wrapper">
                                <img class="product-image" data-role="image-element" src="'.$_src.'" alt="">
                                <div class="actions">
                                </div>
                                <div class="image-fade"><span>Hidden</span></div>
                            </div>
                            <div class="item-description">
                                <div class="item-title" data-role="img-title"></div>
                                <div class="item-size">
                                    <a href="'.$_mediaUrl.'urlrewritesimport/'.$newFileName.'" target="_blank"><span data-role="image-dimens">'.$newFileName.'</span></a>
                                </div>
                            </div>
                        </div>';
                    $data['html'] = $html;
                    if (isset($_postData['feed_id'])) {
                        $data['feed_id'] = $_postData['feed_id'];
                    }
                    if (isset($newFileName)) {
                        $data['filename'] = $newFileName;
                    }
                    $this->_coreSession->setMyData($data);
            }
        }
          $fileData[0] =  json_decode($this->_coreSession->getFiledata0());
          $fileData[1] = json_decode($_postData['file_data1']);
          
        $_result = $this->ImportFile($fileData, $importMode);
           $data = $_result[0];
           $error = $_result[1];
           $message = $_result[2];
           $html22='';
    // Converting object to associative array
            $myArray = json_decode(json_encode($_postData), true);
            if ($myArray['index']==1) {
                if ($message == "Missing required fields to import urlrewrites.Please make sure that the file must have the required fields") {}else{

                $fileinfo = json_decode($myArray['fileinfo'], true);
                
                 $myArray['file'] = $fileinfo['filename'];
                 $myArray['file_data'] = $fileinfo['fileHeading'];
                 $total_UrlReWrites = $fileinfo['totalurlrewritess'];
                $fileRapeat = 0;
                $id = $_postData['feed_id'];
                if (!empty($id)) {
                    $model = $this->_ifac->create()->load($id);
                      
                    if (!$model->getId() && $id) {
                        $data = $this->_coreSession->getMyData();
                        $error = true;
                        $ErrorChek = '';
                        $message= '"This UrlReWritesImportExport no longer exists."';
                        return [ $data, $ErrorChek, $message];
                    }
                } else {
                    unset($myArray['feed_id']);
                    $model = $this->_ifac->create();
                }
                $admin = $this->authSession->getUser();
                $fileName = $myArray['file'];
                $myArray['admin_name'] = $admin->getData('username');
                $model->setData($myArray);
                $this->_bsess->setPageData($model->getData());
                $model->save();
                $data['feed_id'] = $model->getData('feed_id');
                $this->_coreSession->start();
                // set session variables and their value
                $this->_coreSession->setFeedid($data['feed_id']);
                $ImportGridTabmodel = $this->_tgFac->create();
                $ImportGridTabmodel->setfeed_id($model->getData('feed_id'));
                $ImportGridTabmodel->setfile($fileName);
                $ImportGridTabmodel->setadmin($admin->getData('username'));
                $ImportGridTabmodel->setupdated_at($this->_date->date()->format('Y-m-d H:i:s'));
                $ImportGridTabmodel->save();
            }
            $this->_coreSession->start();
            $this->_coreSession->unsFilename();
          }  
        if ($myArray['progress_message']==1) {
           if (!empty($error) && $error !=1) {
            if (!isset($data)) {
                $data = [];
            }
              $csvLineNumb = $index+1;
              $html22 .= '<div style="background-color:pink;">';
              $html22 .= '<p>'.$csvLineNumb.') '.$error.'</p>';
              $html22 .= '</div>';
            }
             $data['html22']=$html22;
        }
         $data['urlrewritesNumber']=$index;

        if (!empty($error) && isset($_result[0]['filename']) && $error != 1) {
            if (!isset($data['feed_id']) || $data['feed_id']=='') {
                $this->_coreSession->start();
              // set session variables and their value
                $data['feed_id'] =  $this->_coreSession->getFeedid();
            }
            $model = $this->_ifac->create()->load($data['feed_id']);
           
            if (!$this->_coreSession->getFilename()) {
              $time=time();
              $currentTime = date("Y-m-d H:i:s", $time);
              $filename = str_replace(".csv", "_".$currentTime.".log", $model->getData('file'));
              $this->_coreSession->start();
              $this->_coreSession->setFilename($filename);  
            }else{
              $filename = $this->_coreSession->getFilename();
            }
            $csvROw = $index+1;
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
                    $logger = new \Zend\Log\Logger();
                    $logger->addWriter($writer);
                    $logger->info("\r\n".$csvROw."->".$error);
        }
         return $resultJson->setData([
                        'message' => $message,
                        'data' => $data,
                        'error' => $error
         ]);
    }// end execute()
     /**
     * check and manipulate data to import
     *
     * @return  success/failed message 
     */
    public function ImportFile($fileData, $importMode)
    {
      $SampleArray=["entity_type","request_path","new_request_path","target_path","redirect_type","store_id"];
       
      foreach ($SampleArray as $key => $value) {
        if (!in_array($value, $fileData[0])) {
            $data = $this->_coreSession->getMyData();
            $error = true;
            $message = "Missing required fields to import UrlReWrites.Please make sure that the file must have the required fields";
         return [ $data, $error, $message];
        }
      } 
      foreach ($fileData[0] as $ke => $vale) {
       if ($vale != 'new_request_path') {
         $urlrewritesData[$vale] = $fileData[1][$ke];
       }else{
          $newRequestPath = $fileData[1][$ke];
       }
      }
      if ($importMode!=2) {
       $urlrewritesData = $this->checkData($urlrewritesData);
       $result = $this->is_multi($urlrewritesData);
       if ($result=='TRUE') {
         return $urlrewritesData; 
       }
      }
      $result = $this->helperData->urlrewritesInsert($urlrewritesData, $importMode, $newRequestPath);
        if (empty($result)) {
            $data = $this->_coreSession->getMyData();
            $error = true;
            $ErrorChek = "your file has no data to import";
            $message= '';
            return [ $data, $ErrorChek, $message];
        } else {
            $error = $result[1];
            $data = $result[0];
            if (!isset($data)) {
                $data = [];
            }
            $message = $result[2];
        }
        return [ $data, $error, $message];
    }//ImportFile()
     /**
     * check and manipulate data to import
     *
     * @return  success/failed message 
     */
    public function checkData($urlrewritesData)
    {
      if ($urlrewritesData['target_path'] == '') {
         $data = $this->_coreSession->getMyData();
         $ErrorChek = 'Invalid target path';
         $message= '';
        return [ $data, $ErrorChek, $message];
      }
      if ($urlrewritesData['request_path'] == '') {
         $data = $this->_coreSession->getMyData();
         $ErrorChek = 'Invalid request path';
         $message= '';
        return [ $data, $ErrorChek, $message];
      }
      if (!empty($urlrewritesData['store_id'])) {
        try {
            $storeData = $this->_storeManager->getStore($urlrewritesData['store_id']);
        } catch (\Magento\Framework\Exception\LocalizedException $localizedException) {
           $data = $this->_coreSession->getMyData();
           $ErrorChek = 'The store id '.$urlrewritesData['store_id'].' does not exist.';
           $message= '';
          return [ $data, $ErrorChek, $message];
        }
      }else{
         $data = $this->_coreSession->getMyData();
         $ErrorChek = 'Invalid store id';
         $message= '';
        return [ $data, $ErrorChek, $message];
      }
      if ($urlrewritesData['entity_type'] == 'cms-page') {
        if(strpos($urlrewritesData['target_path'], 'cms/page/view/page_id/') !== false){
            $pageId = ltrim($urlrewritesData['target_path'],"cms/page/view/page_id/");
            $cmsId = $this->query->cmsPageIdExist($pageId);
            if (empty($cmsId)) {
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The cms page id '.$pageId.' does not exist';
               $message= '';
              return [ $data, $ErrorChek, $message];
            }
            $urlrewritesData['entity_id'] = $pageId;
           return $urlrewritesData;
        } else{
             $data = $this->_coreSession->getMyData();
             $ErrorChek = 'Invalid target path';
             $message= '';
            return [ $data, $ErrorChek, $message];
        }
      }
      if ($urlrewritesData['entity_type'] == 'category') {
        if(strpos($urlrewritesData['target_path'], 'catalog/category/view/id/') !== false){
            $catId = ltrim($urlrewritesData['target_path'],"catalog/category/view/id/");
            $categoryId = $this->query->categoryIdExist($catId);
            if (empty($categoryId)) {
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The category id '.$catId.' does not exist';
               $message= '';
              return [ $data, $ErrorChek, $message];
            }
           $urlrewritesData['entity_id'] = $catId; 
           return $urlrewritesData;
        } else{
             $data = $this->_coreSession->getMyData();
             $ErrorChek = 'Invalid target path';
             $message= '';
            return [ $data, $ErrorChek, $message];
        }
      }
      if ($urlrewritesData['entity_type'] == 'product') {
        if(strpos($urlrewritesData['target_path'], 'catalog/product/view/id/') !== false){
          if(strpos($urlrewritesData['target_path'], '/category/') !== false){
            preg_match_all('!\d+!', $urlrewritesData['target_path'], $matches);
            $prdCatId = call_user_func_array('array_merge', $matches);
            if (isset($prdCatId[0])) {
              $prodId = $this->query->productIdExist($prdCatId[0]);
              if (empty($prodId)) {
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The product id '.$prdCatId[0].' does not exist';
               $message= '';
              return [ $data, $ErrorChek, $message];
              }
            }else{
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The target path has no product id';
               $message= '';
              return [ $data, $ErrorChek, $message];
            }
            if (isset($prdCatId[1])) {
              $catId = $this->query->categoryIdExist($prdCatId[1]);
              if (empty($catId)) {
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The category id '.$prdCatId[1].' does not exist';
               $message= '';
              return [ $data, $ErrorChek, $message];
              }
            }else{
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The target path has no category id';
               $message= '';
              return [ $data, $ErrorChek, $message];
            }
             $urlrewritesData['entity_id'] = $prdCatId[0];
             return $urlrewritesData;
           }else{
             $proId = ltrim($urlrewritesData['target_path'],"catalog/product/view/id/");
             $prodId = $this->query->productIdExist($proId);
             if (empty($prodId)) {
               $data = $this->_coreSession->getMyData();
               $ErrorChek = 'The product id '.$proId.' does not exist';
               $message= '';
              return [ $data, $ErrorChek, $message];
              }
             $urlrewritesData['entity_id'] = $prodId; 
             return $urlrewritesData;
           }
         }else{
             $data = $this->_coreSession->getMyData();
             $ErrorChek = 'Invalid target path';
             $message= '';
            return [ $data, $ErrorChek, $message];
         }
      }
      if ($urlrewritesData['entity_type'] == 'custom') {
             $urlrewritesData['entity_id'] = 0;
             return $urlrewritesData;
      }else{
             $data = $this->_coreSession->getMyData();
             $ErrorChek = 'Invalid entity type';
             $message= '';
            return [ $data, $ErrorChek, $message];
      }
    }//checkData()
      /**
   * check array is multi or uni
   *
   * @return bolean
   */
    public function is_multi($arr)
    {
        foreach ($arr as $v) {
            if (is_array($v)) {
                 return "TRUE";
            }
        }
        return "FALSE";
    }//end is_multi()
}
