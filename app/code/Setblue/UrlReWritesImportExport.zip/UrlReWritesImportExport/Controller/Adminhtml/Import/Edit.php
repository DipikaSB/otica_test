<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Backend\App\Action;
use Magento\Backend\Model\Session;

class Edit extends \Magento\Backend\App\Action
{
   /**
    * Core registry
    *
    * @var \Magento\Framework\Registry
    */
    protected $_coreRegistry = null;
    protected $_ifac;
    protected $_bsess;

     /**
      *  Result Page Factory
      *
      * @var \Magento\Framework\View\Result\PageFactory
      */
    protected $resultPageFactory;
    /**
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Setblue\UrlReWritesImportExport\Model\ImportFactory $ifac,
        \Magento\Framework\Registry $registry,
        Session $bsess
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->messageManager = $messageManager;
        $this->_coreRegistry = $registry;
        $this->_ifac = $ifac;
        $this->_bsess = $bsess;
        parent::__construct($context);
    }//end __construct()
     /**
      * Initialization Action
      *
      * @return object
      */
    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Setblue_UrlReWritesImportExport::setblue_urlrewritesimportexport')
            ->addBreadcrumb(__('UrlReWritesImportExport'), __('UrlReWritesImportExport'))
            ->addBreadcrumb(__('Manage Feed'), __('Manage Feed'));
        return $resultPage;
    }//end _initAction()

     /**
      * Main function of this class
      *
      * @return \Magento\Backend\Model\View\Result\Page $resultPage
      */
    public function execute()
    {
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('feed_id');
        $model = $this->_ifac->create();
        // 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getFeedId()) {
                $this->messageManager->addError(__('This record no longer exists.'));
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
        // 3. Set entered data if was error when we do save
        $data = $this->_bsess->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
        $this->_coreRegistry->register('setblue_urlrewritesimportexport_data', $model);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit UrlReWritesImportExport') : __('New UrlReWritesImportExport'),
            $id ? __('Edit UrlReWritesImportExport') : __('New UrlReWritesImportExport')
        );
         $resultPage->getConfig()
              ->getTitle()
              ->prepend(__('Import'));
        $resultPage->getConfig()
              ->getTitle()
              ->prepend($model->getId() ? $model->getName() : __('URL ReWrites Import'));
        return $resultPage;
    }// end execute()
}// end class
