<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Framework\Json\Helper\Data as JsonHelper;
use \Magento\Framework\Stdlib\DateTime;

class AddAttachment extends \Magento\Backend\App\Action
{
    
   
    
    protected \Magento\Framework\Filesystem\Directory\WriteInterface $_mediaDirectory;
    protected \Magento\Framework\Session\SessionManagerInterface $_coreSession;
    protected \Magento\MediaStorage\Model\File\UploaderFactory $_fileUploaderFactory;
    protected \Magento\Store\Model\StoreManagerInterface $_storeManager;
    protected \Magento\Framework\Filesystem\Driver\File $_fileDriver;
    protected \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory;
    protected \Magento\Framework\File\Csv $csvProcessor;
    protected \Magento\Framework\App\Filesystem\DirectoryList $directoryList;
    protected \Setblue\UrlReWritesImportExport\Helper\Data $helperData;
    protected \Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Renderer\UploadFile $block;


    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Renderer\UploadFile $block,
        \Magento\Framework\Filesystem\Driver\File $fileDriver,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Setblue\UrlReWritesImportExport\Helper\Data $helperData,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_fileDriver = $fileDriver;
        $this->csvProcessor = $csvProcessor;
        $this->block = $block;
        $this->_coreSession = $coreSession;
        $this->helperData = $helperData;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->directoryList = $directoryList;
        $this->_storeManager = $storeManager;
    }
     /**
      * permission method in admin controller
      *
      * @return true
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Setblue_UrlReWritesImportExport::urlrewrites_import');
    }//end _isAllowed()
     /**
      * Call to two function Upload file and Import File
      *
      * @return
      */
    public function execute()
    {
        $_postData = $this->getRequest()->getPost();
        $resultJson = $this->resultJsonFactory->create();
        $_result = $this->UploadFile();
        if (isset($_result[3])) {
            foreach ($_result[3] as $key => $value) {
                 $fileCollection[] = json_encode($value);
            }
            $fileCollection = json_encode($fileCollection);
        } else {
            $fileCollection = '';
        }
           $data = $_result[0];
           $error = $_result[1];
           $message = $_result[2];
            return $resultJson->setData([
                        'message' => $message,
                        'data' => $data,
                        'error' => $error,
                        'fileData' => $fileCollection
            ]);
    }
    /**
     * upload csv/xml file
     *
     * @return
     */
    public function UploadFile()
    {
        $_postData = $this->getRequest()->getPost();
        $message = "";
        $newFileName = "";
        $error = false;
        $data = [];
        try {
            $target = $this->_mediaDirectory->getAbsolutePath('urlrewritesimport/');
            try {
                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'attachment']);
                $_fileType = $uploader->getFileExtension();
                if ($_fileType != $_postData['file_extension']) {
                     $error = true;
                     $message = "Uploaded file Does not match with the Selected data format";
                     return [ $data, $error, $message];
                }
                $uploader->setAllowRenameFiles(true);
                $uploader->setAllowedExtensions(['csv']);
                $result = $uploader->save($target);
            } catch (\Exception $e) {
                 $error = true;
                 $message = "File was not uploaded because your uploaded file is larger than server upload limit.";
                 return [ $data, $error, $message];
            }
            if ($result['file']) {
                $newFileName = $result['file'];
                $_mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

                if ($this->_fileDriver->isExists($this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA). '/urlrewritesimport/default/icon-csv.png')) {
                    $_iconArray = [
                    'csv' => $_mediaUrl.'urlrewritesimport/default/icon-csv.png',
                    ];
                }
                if (isset($_iconArray[$_fileType])) {
                    $_src = $_iconArray[$_fileType];
                } else {
                    $_src = $_mediaUrl.'urlrewritesimport/'.$newFileName;
                }
                $filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA).'/urlrewritesimport/'.$newFileName;
                    $delimiter = $this->helperData->getFileDelimiter($filePath);
                if (is_array($delimiter)) {
                    $error = true;
                      $message = "Your file has no data to import.";
                      return [ $data, $error, $message];
                }
                if ($delimiter != ',') {
                    $error = true;
                    $message = "Your CSV file delimiter is not a comma seprated.";
                    return [ $data, $error, $message];
                }
                    $dataComplete = $this->csvProcessor->getData($filePath);
                    $totalUrlReWritess = sizeof($dataComplete)-1;
                if ($totalUrlReWritess<=0) {
                      $error = true;
                      $message = "Your file has no data to import.";
                      return [ $data, $error, $message];
                }

                $SampleArray=["entity_type","request_path","new_request_path","target_path","redirect_type","store_id"];
                 
                foreach ($SampleArray as $key => $value) {
                    if (!in_array($value, $dataComplete[0])) {
                        $error = true;
                        $message = "Your uploaded file doesn't match with sample file.";
                        return [ $data, $error, $message];
                    }
                }
                
                $error = false;
                $message = "File has been successfully uploaded";
                $html = '<div class="image item base-image" data-role="image" id="'. uniqid().'">
                            <div class="product-image-wrapper">
                                <img class="product-image" data-role="image-element" src="'.$_src.'" alt="">
                                <div class="actions">
                                </div>
                                <div class="image-fade"><span>Hidden</span></div>
                            </div>
                            <div class="item-description">
                                <div class="item-title" data-role="img-title"></div>
                                <div class="item-size">
                                    <a href="'.$_mediaUrl.'urlrewritesimport/'.$newFileName.'" target="_blank"><span data-role="image-dimens">'.$newFileName.'</span></a>
                                </div>
                            </div>
                        </div>';

                $data = ['filename' => $newFileName, 'path' => $_mediaUrl.'urlrewritesimport/'.$newFileName, 'fileType' => $_fileType, 'html' => $html];
                $myJSONFile = json_encode($dataComplete[0]);
                $data['fileInformation']['fileHeading'] = $myJSONFile;
                $data['fileInformation']['filename'] = $newFileName;
                $data['fileInformation']['totalurlrewritess'] = $totalUrlReWritess;
                $data['fileInformation'] = json_encode($data['fileInformation']);
                $data['feed_id'] = $_postData['feed_id'];
                $this->_coreSession->start();
                $this->_coreSession->setMyData($data);
            }
        } catch (\Exception $e) {
            $error = true;
            $message = $e->getMessage();
            return [ $data, $error, $message];
        }
        return [ $data, $error, $message , $dataComplete];
    }// end UploadFile()
}
