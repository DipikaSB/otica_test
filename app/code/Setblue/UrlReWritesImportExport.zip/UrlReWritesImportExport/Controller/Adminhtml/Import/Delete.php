<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Import;

use Magento\Backend\App\Action;

/**
 * Delete Profile
 *
 * @api
 * @since 100.0.2
 */
class Delete extends Action
{

    /**
     *
     * @var  \Setblue\UrlReWritesImportExport\Model\Import
     */
    protected $_model;
    public function __construct(
        Action\Context $context,
        \Setblue\UrlReWritesImportExport\Model\Import $model
    ) {
        parent::__construct($context);
        $this->_model = $model;
    }
     /**
      * Delete profile against id
      *
      * @return true
      */
    public function execute()
    {
        $id = $this->getRequest()->getParam('feed_id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->_model;
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccess(__('UrlReWrites Import Profile '.$id.' Deleted'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['feed_id' => $id]);
            }
        }
        $this->messageManager->addError(__('UrlReWrites Import Profile does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}
