<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use \Magento\Framework\Exception\NotFoundException;

class Index extends \Magento\Backend\App\Action
{
    /**
     * $resultPageFactory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory = false;
    protected $_messageManager;

    protected $helperData;

    
     /**
      * @param\Magento\Backend\App\Action\Context $context
      * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
      */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Setblue\UrlReWritesImportExport\Helper\Data $helperData,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_messageManager = $messageManager;
        $this->helperData = $helperData;
    }

    /**
     * Default customer account page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend((__('URL ReWrites Export')));
        return $resultPage;
    }
}
