<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use Magento\Backend\App\Action;
use \Magento\Framework\Exception\NotFoundException;

class Delete extends Action
{
    /**
     * _productVisibility
     *
     * @var  \Setblue\UrlReWritesImportExport\Model\Post
     */
    protected $model;
    /**
     * _file
     *
     * @var  \Magento\Framework\Filesystem\Driver\File
     */
    protected $_file;

     /**
      * @param \Magento\Framework\Filesystem\Driver\File $file
      * @param \Magento\Framework\App\Filesystem\DirectoryList $directoryList
      * @param \Setblue\UrlReWritesImportExport\Model\Post $model
      */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Setblue\UrlReWritesImportExport\Model\Post $model,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->_file = $file;
        $this->directoryList = $directoryList;
        $this->_messageManager = $messageManager;
        parent::__construct($context);
        $this->_model = $model;
    }//end __construct()
    /**
     * Delete action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('export_id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $model = $this->_model;
                $model->load($id);
                
                $filename = $model->getData('file_name');
                $dir = $model->getData('url_key');
                
                $checkfile = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA). $dir.$filename.'.csv';
                if (file_exists($checkfile)) {
                    $this->_file->deleteFile($checkfile);
                }
                
                $model->delete();
                $this->messageManager->addSuccess(__('Profile '.$id.' deleted'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['export_id' => $id]);
            }
        }
        $this->messageManager->addError(__('Profil does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}
