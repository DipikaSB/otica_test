<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use \Magento\Framework\Exception\NotFoundException;
use Magento\Backend\Model\Session;

class Save extends \Magento\Backend\App\Action
{
    protected $messageManager;
    protected $_date;
    protected $_pfac;
    protected $_bsess;
    
     /**
      * @param\Magento\Backend\App\Action\Context $context
      * @param \Magento\Framework\View\Result\PageFactory $_messageManagerq
      */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        Session $bsess,
        \Setblue\UrlReWritesImportExport\Model\PostFactory $pfac,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        parent::__construct($context);
        $this->messageManager = $messageManager;
        $this->_date =  $date;
        $this->_pfac =  $pfac;
        $this->_bsess = $bsess;
    }
    /**
     * Save design action.
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $resultRedirect = $this->resultRedirectFactory->create();
            $model = $this->_pfac->create();
        if (!isset($data['export_id'])) {
            $data['export_id'] = null;
        }
           $id=$data['export_id'];
        if ($id) {
            $model->load($id);
        }
        if ($id =='') {
            $randomfilename = $this->_date->date()->format('Y-m-d H:i:s');
            $data['file_name'] = $data['file_name'].'_'.$randomfilename;
        }
             $model->setData($data);
            $this->_bsess->setPageData($model->getData());

        try {
            $model->save();
            $this->messageManager->addSuccess(__('Profile saved successfully.'));
            $this->_bsess->setFormData(false);
            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', ['export_id' => $model->getId(), '_current' => true]);
            }
            return $resultRedirect->setPath('*/*/');
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\RuntimeException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the profile.'));
        }
            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['export_id' => $this->getRequest()->getParam('export_id')]);
        return $resultRedirect->setPath('*/*/');
    }//end execute
}
