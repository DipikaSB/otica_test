<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

class NewAction extends \Magento\Backend\App\Action
{
   /**
    * resultForwardFactory
    *
    * @var  \Magento\Backend\Model\View\Result\ForwardFactory
    */
    protected $resultForwardFactory;
    /**
     * @param Context $context
     * @param ForwardFactory $resultForwardFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory
    ) {
        $this->resultForwardFactory = $resultForwardFactory;
        parent::__construct($context);
    }//end __construct()
   /**
    * @return \Magento\Framework\Controller\Result\Forward
    */
    public function execute()
    {
        $resultForward = $this->resultForwardFactory->create();
        return $resultForward->forward('edit');
    }
}
