<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Setblue\UrlReWritesImportExport\Model\ResourceModel\Post\CollectionFactory;
use \Magento\Framework\Exception\NotFoundException;

class MassDelete extends \Magento\Backend\App\Action
{
     /**
      * filter
      *
      * @var  Magento\Ui\Component\MassAction\Filter
      */
    protected $filter;
     /**
      * collectionFactory
      *
      * @var  Setblue\UrlReWritesImportExport\Model\ResourceModel\Post\CollectionFactory
      */
    protected $collectionFactory;
     /**
      * _coreResource
      *
      * @var \Magento\Framework\App\ResourceConnection
      */
    protected $_coreResource;
     /**
      * _file
      *
      * @var  \Magento\Framework\Filesystem\Driver\File
      */
    protected $_file;
    /**
     * @param Magento\Ui\Component\MassAction\Filter $filter
     * @param Setblue\UrlReWritesImportExport\Model\ResourceModel\Post\CollectionFactoryry $collectionFactory
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param  \Magento\Framework\App\Filesystem\DirectoryList $directoryList
     * @param \Magento\Framework\App\ResourceConnection $coreResource
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Magento\Framework\App\ResourceConnection $coreResource,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->filter = $filter;
        $this->_coreResource = $coreResource;
        $this->_file = $file;
        $this->directoryList = $directoryList;
        $this->_messageManager = $messageManager;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }//end __construct()
    /**
     * Delete backups mass action
     *
     * @return \Magento\Backend\App\Action
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());

        $collectionSize = $collection->getSize();
        foreach ($collection as $item) {
            $filename = $item->getData('file_name');
            $dir = $item->getData('url_key');
            
            $checkfile = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA). $dir.$filename.'.csv';
            if (file_exists($checkfile)) {
                $this->_file->deleteFile($checkfile);
            }
            $this->deleteData($item->getId());
        }

        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $collectionSize));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }

    public function deleteData($id)
    {
        $writeconnection = $this->_coreResource->getConnection('core_write');
        $readconnection = $this->_coreResource->getConnection('core_read');
        $posttable = $this->_coreResource->getTableName('setblue_urlrewritesimportexport_export');
      // deleting data from customer group table before insertion
            $selectdatasql2 = 'select * from ' . $posttable . ' where (export_id = ' . $id . ')';
            $result4 = $readconnection->fetchAll($selectdatasql2);
        if (sizeof($result4) > 0) {
            $deletesql1 = 'delete from ' . $posttable . ' where (export_id = ' . $id . ')';
            $result3 = $writeconnection->query($deletesql1);
        }
    }
}
