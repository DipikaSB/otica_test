<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use Magento\Backend\App\Action;
use Magento\Backend\Model\Session;

class Edit extends \Magento\Backend\App\Action
{
     /**
      * Core registry
      *
      * @var \Magento\Framework\Registry
      */
    protected $_coreRegistry = null;
     /**
      *  Result Page Factory
      *
      * @var \Magento\Framework\View\Result\PageFactory
      */
    protected $resultPageFactory;
    protected $_pfac;
    protected $_bsess;
    protected $messageManager;

    /**
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        Session $bsess,
        \Setblue\UrlReWritesImportExport\Model\PostFactory $pfac,
        \Magento\Framework\Registry $registry
    ) {
         
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        $this->_pfac =  $pfac;
        $this->_bsess = $bsess;
        $this->messageManager = $messageManager;
        parent::__construct($context);
    }//end __construct()

     /**
      * Initialization Action
      *
      * @return object
      */
    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Setblue_UrlReWritesImportExport::setblue_urlrewritesimportexport')
            ->addBreadcrumb(__('UrlReWritesImportExport'), __('UrlReWritesImportExport'))
            ->addBreadcrumb(__('Manage Feed'), __('Manage Feed'));
        return $resultPage;
    }//end _initAction()
     /**
      * Main function of this class
      *
      * @return \Magento\Backend\Model\View\Result\Page $resultPage
      */
    public function execute()
    {
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('export_id');
        $model = $this->_pfac->create();
        // 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This record no longer exists.'));
               
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
        // 3. Set entered data if was error when we do save
        $data = $this->_bsess->getFormData(true);
   
        if (!empty($data)) {
            $model->setData($data);
        }
        // $model->getConditions()->setJsFormObject('rule_conditions_fieldset');
        
        $this->_coreRegistry->register('setblue_urlrewritesimportexport_data', $model);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit UrlReWritesImportExport') : __('New UrlReWritesImportExport'),
            $id ? __('Edit UrlReWritesImportExport') : __('New UrlReWritesImportExport')
        );
         $resultPage->getConfig()
              ->getTitle()
              ->prepend(__('Post'));
        $resultPage->getConfig()
              ->getTitle()
              ->prepend($model->getId() ? $model->getName() : __('URL ReWrites Export'));
        return $resultPage;
    }// end execute()
}// end class
