<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use \Magento\Framework\App\Action\Action;
use \Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Filesystem\Io\File;
use Magento\Backend\Model\Session;
use Magento\Framework\App\Response\Http;

class GenerateFileFromGrid extends Action
{
   /**
    * csvProcessor
    *
    * @var  \Magento\Framework\File\Csv
    */
    private $csvProcessor;
    /**
     * directoryList
     *
     * @var  \Magento\Framework\App\Filesystem\DirectoryList
     */
    private $directoryList;
    /**
     * @var string array
     */
    private $output;
     /**
      * model
      *
      * @var  \Setblue\UrlReWritesImportExport\Model\Post
      */
    protected $model;
    protected $_model;
    protected $field;
    protected $_io;
    protected $_date;
    protected $_gridtabmodel;
    protected $_pfac;
    protected $_tgfac;
    protected $_bsess;
    protected $response;
    protected $zipArchive;
    protected $resultRedirect;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
     /**
      * @param \Magento\Framework\App\Action\Context $context
      * @param \Magento\Framework\Controller\ResultFactory $result
      * @param \Magento\Framework\File\Csv $csvProcessor
      * @param \Magento\Framework\App\Filesystem\DirectoryList $directoryList
      * @param \Setblue\UrlReWritesImportExport\Model\Post $model
      * @param string array $output
      */

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\ResultFactory $result,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        \Setblue\UrlReWritesImportExport\Model\Post $model,
        \Setblue\UrlReWritesImportExport\Model\ResourceModel\Post $field,
        \Setblue\UrlReWritesImportExport\Model\TabGrid $gridtabmodel,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        Session $bsess,
        Http $httpResponse,
        \Setblue\UrlReWritesImportExport\Model\PostFactory $pfac,
        \Setblue\UrlReWritesImportExport\Model\TabGridFactory $tgfac,
        File $io,
        \Magento\Framework\Archive\Zip $zipArchive
    ) {
        $this->field = $field;
        $this->resultRedirect = $result;
        $this->directoryList = $directoryList;
        $this->csvProcessor = $csvProcessor;
        $this->_io = $io;
        $this->_date =  $date;
        $this->messageManager = $messageManager;
        $this->zipArchive = $zipArchive;
        parent::__construct($context);
        $this->_model = $model;
        $this->_gridtabmodel = $gridtabmodel;
        $this->_pfac =  $pfac;
        $this->_tgfac =  $tgfac;
        $this->_bsess = $bsess;
        $this->response = $httpResponse;
    } //end __construct()
  /**
   * permission method in admin controller
   *
   * @return true
   */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Setblue_UrlReWritesImportExport::urlrewrites_export');
    }//end _isAllowed()
   
    public function execute()
    {
        $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
        $id = $this->getRequest()->getParam('export_id');
        $model = $this->_pfac->create();
        if ($id) {
            $model->load($id);
            $data = $model->getData();
            if ($data) {
                $message = $this->Csv($data);
            } else {
                $this->messageManager->addError(__("Unknown Request....."));
            }
        } else {
            $this->messageManager->addError(__("Invalid Request....."));
        }
        return $resultRedirect->setPath('*/*/index');
    }
    //end execute()
    /**
     * Generate csv
     *
     * @return CSV file
     */
    public function Csv($data)
    {
        $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
        if ($data) {
            $model = $this->_pfac->create();
            $gridtabmodel = $this->_tgfac->create();
            $id = $data['export_id'];
            if ($id) {
                $model->load($id);
            }
            if (strpos($data['file_name'], '_') !== false) {
                $randomfilename = $this->_date->date()->format('Y-m-d H:i:s');
                $newstring = substr($data['file_name'], -19);
                $data['file_name'] = str_replace($newstring, $randomfilename, $data['file_name']);
            } else {
                $randomfilename = $this->_date->date()->format('Y-m-d H:i:s');
                $data['file_name'] = $data['file_name'].'_'.$randomfilename;
            }
             $model->setData($data);
           
            $this->_bsess->setPageData($model->getData());

            $store_id = $model->getData('store_id');
            $salesUrlReWritesTableData = $this->field->getAllFieldsData($model->getData());
            $directory = $model->getData('url_key');
            $filenam = $model->getData('file_name');
            $fileName = $filenam.'.csv';
            $file_name = $filenam.'.zip';
           
            try {
                $strcount = strlen($directory);
            
                preg_match('^\/([A-z0-9-_+]+\/)*([A-z0-9]+\/)$^', $directory, $matches);
                if ($strcount==1) {
                     $matches='/';
                }
                if (!empty($matches) && $directory[0] =='/') {
                    $directory = $matches[0];
                    $filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA). $directory;

                    if (!file_exists($filePath)) {
                         $this->_io->mkdir($filePath, 0777);
                    }
                    $filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                    . $directory.$fileName;

                    $Zippath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                    . $directory.$file_name;

                    $output=[];
                    $model->save();
     
              // For heading in csv file....................
                    $this->output[0] = explode(",", substr_replace($this->field->TableInfo(), 'new_request_path,', 35, 0));
                    foreach ($salesUrlReWritesTableData as $ke => $v) {
                        foreach ($v as $ky => $vlue) {
                            $count=$ke+1;
                            $this->output[$count][]=$vlue;
                            if ($ky == 'request_path') {
                                $this->output[$count][]='';
                            }
                        }
                    }
                    if (isset($this->output[1])) {
                        $this->csvProcessor
                        ->setEnclosure('"')
                        ->saveData(
                            $filePath,
                            $this->output
                        );
// file also save in zip form with same name 
                        $this->zipArchive->pack($filePath, $Zippath);

                        $fileSize = filesize($filePath);
                        if ($fileSize < '1024') {
                              $modifiedFileSize = $fileSize."B";
                        } elseif ($fileSize > 1024 && $fileSize < (1024 * 1024)) {
                            $modifiedFileSize = round(($fileSize / 1024 * 100.0)) / 100.0."KB";
                        } else {
                            $modifiedFileSize = round(($fileSize / (1024 * 1204) * 100.0)) / 100.0."MB";
                        }
                        $gridtabmodel->setexport_id($id);
                        $gridtabmodel->setfile_size($modifiedFileSize);
                        $gridtabmodel->setfilename($model->getData('file_name'));
                        $gridtabmodel->seturl_path($model->getData('url_key'));
                        $gridtabmodel->setupdated_at($this->_date->date()->format('Y-m-d H:i:s'));
                        $gridtabmodel->save();
                        $this->messageManager->addSuccess(__($fileName.' export successfully.'));
                        $this->_bsess->setFormData(false);
                        return $resultRedirect->setPath('*/*/index');
                         // return $this->response->setRedirect($url);
                    } else {
                        $this->messageManager->addError(__('There is no data to Export'));
                    }
                } else {
                    $this->messageManager->addError(__('Invalid Directory.'));
                }
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __($e.'Something went wrong while generate the profile.'));
            }
            return $resultRedirect->setPath('*/*/index');
            // return $this->response->setRedirect($url);
        }
        $this->messageManager->addError(__('Form is empty'));
        return $resultRedirect->setPath('*/*/index');
        // return $this->response->setRedirect($url);
    }//end CSV()
} //end class
