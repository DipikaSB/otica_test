<?php

namespace Setblue\UrlReWritesImportExport\Controller\Adminhtml\Post;

use Magento\Framework\Registry;

class Blocks extends \Magento\Backend\App\Action
{
    /**
     * ResultLayout Factory
     *
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $_resultLayoutFactory;
    protected $_pfac;
    protected $_registry;
    
    
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\LayoutFactory $layoutFactory
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $layoutFactory,
        \Setblue\UrlReWritesImportExport\Model\PostFactory $pfac,
        Registry $registry
    ) {

        $this->_resultLayoutFactory = $layoutFactory;
        $this->_pfac = $pfac;
        $this->_registry = $registry;
        parent::__construct($context);
    }//end __construct()
    /**
     * Default urlrewrites export grid page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $resultLayout = $this->_resultLayoutFactory->create();
        $this->_initRuleblocks();

        $resultLayout->getLayout()
                ->getBlock('setblue_urlrewritesimportexport.edit.tab.blocks')
                ->setRelatedBlocks($this->getRequest()->getPost('related_blocks', null));
        return $resultLayout;
    }//end execute()
    /**
     * Initialization Rule
     *
     * @return object
     */
    protected function _initRuleBlocks()
    {

        $rule = $this->_pfac->create();
        $ruleId = (int) $this->getRequest()->getParam('export_id');

        if ($ruleId) {
            $rule->load($ruleId);
        }

        $this->_registry->register('current_urlrewritesimportexport_blocks', $rule);
        return $rule;
    }//end _initRuleBlocks()
}
