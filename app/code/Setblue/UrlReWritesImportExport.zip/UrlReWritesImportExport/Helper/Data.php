<?php

namespace Setblue\UrlReWritesImportExport\Helper;

use Magento\Store\Model\Store;
use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var  \Magento\Framework\Session\SessionManagerInterface
     */
    /** session to save Data*/
    protected $_coreSession;

    protected $csvProcessor;
    protected $query;
    protected $customerFactory;
    protected $_resource;
     /**
      * @var   \Magento\Store\Model\StoreManagerInterface
      */
    public $_storeManager;
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Setblue\UrlReWritesImportExport\Model\ResourceModel\Import $query,
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->csvProcessor = $csvProcessor;
        $this->query = $query;
        $this->_coreSession = $coreSession;
        $this->customerFactory = $customerFactory;
        $this->_storeManager = $storeManager;
        $this->_resource = $resource;
        parent::__construct($context);
    }
     /**
      * write error in log file
      *
      * @return empty
      */
    public function logFile($value, $_result)
    {
            $time=time();
            $currentTime = date("Y-m-d H:i:s", $time);
             $filename = str_replace(".csv", "_".$currentTime.".log", $value['file']);
        $string = '';
        foreach ($_result as $kye => $vle) {
                  $string .= "\r\n".$vle;
        }
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$filename);
                    $logger = new \Zend\Log\Logger();
                    $logger->addWriter($writer);
                    $logger->info("\r\n".$string);
            return;
    }//end logFile()
    /**
     * getFile collection
     *
     * @return array
     */
    public function getFileData($value, $filePath)
    {
        try {
                $delimiter = $this->getFileDelimiter($filePath);
            if (is_array($delimiter)) {
                $error = true;
                $data = '';
                $message = "Your file has no data to import.";
                return [ $data, $error, $message];
            }
            if ($delimiter != ',') {
                $error = true;
                $data = '';
                $message = "Your CSV file delimiter is not a comma seprated.";
                return [ $data, $error, $message];
            }
                $dataComplete = $this->csvProcessor->getData($filePath);
               return $dataComplete;
        } catch (\Exception $e) {
              $error = true;
              $data = '';
              $message = "Something went wrong while reading file.";
              return [ $data, $error, $message];
        }
    }//end getFileData()
     /**
      * check file delimiter is valid or not
      *
      * @return delimiter/empty
      */
    public function getFileDelimiter($file)
    {
        try {
            if (($handle = fopen($file, "r")) !== false) {
                $delimiters = [',', ';', '|', ':']; //Put all that need check

                foreach ($delimiters as $item) {
                    //fgetcsv() return array with unique index if not found the delimiter
                    if (count(fgetcsv($handle, 0, $item, '"')) > 1) {
                        $delimiter = $item;
                        break;
                    }
                }
            }
            return (isset($delimiter) ? $delimiter : null);
        } catch (\Exception $e) {
            $error = true;
            $data = '';
            $message = "Your file has no data to import.";
            return [ $data, $error, $message];
        }
    }//end getFileDelimiter()
    
  /**
   * Receive urlrewrites one by one and then update/insert into database
   *
   * @return arreay
   */
    public function urlrewritesInsert($urlrewriteData, $importMode, $newRequestPath)
    {
        try {
              $chkUpdate ='';
              $chkInsert ='';
            if ($importMode==2) {
                $rewriteId =  $this->query->CheckUrlReWriteExist($urlrewriteData['request_path'], $urlrewriteData['store_id']);
                if (empty($rewriteId)) {
                    $data = $this->_coreSession->getMyData();
                    $ErrorChek = 'The request path ('.$urlrewriteData['request_path'].') does not exist.';
                    $message= '';
                    return [ $data, $ErrorChek, $message];
                }
                $this->query->DeleteUrlReWrites($urlrewriteData['request_path'], $urlrewriteData['store_id']);
                $this->_coreSession->start();
                $error = false;
                $data = $this->_coreSession->getMyData();
                $message = "successfully urlrewrite Deleted.";
                return [ $data, $error, $message];
            }
            if ($importMode==1) {
                $this->query->DeleteUrlReWrites($urlrewriteData['request_path'], $urlrewriteData['store_id']);
            }
              $rewriteId =  $this->query->CheckUrlReWriteExist($urlrewriteData['request_path'], $urlrewriteData['store_id']);

            if (!empty($rewriteId) && $importMode == 0) {
                if (!empty($newRequestPath)) {
                    $new_request_path =  $this->query->NewUrlReWriteTYpeExist($newRequestPath,$urlrewriteData['store_id']);
                    if (!empty($new_request_path)) {
                        $data = $this->_coreSession->getMyData();
                        $ErrorChek = 'This new request path ('.$newRequestPath.') alrady exist.';
                        $message= '';
                        return [ $data, $ErrorChek, $message];
                    }
                }
                $chkUpdate ='TRUE';
            } else {
                $chkInsert='TRUE';
            }
       // Data Update in a Database............................
            if ($chkUpdate=='TRUE') {
                $checkError = $this->query->UpdateUrlReWritesData($urlrewriteData, $newRequestPath);
                if (!empty($checkError)) {
                    return $checkError;
                }
            }
       // Data Insert in a Database............................
            if ($chkInsert=='TRUE') {
                $checkInsertError = $this->query->InsertUrlReWritesData($urlrewriteData);
                if (!empty($checkInsertError)) {
                    return $checkInsertError;
                }
            }
        } catch (\Exception $e) {
            $data = $this->_coreSession->getMyData();
            $ErrorChek =$e->getMessage();
            $message= '';
            return [ $data, $ErrorChek, $message];
        }
           $this->_coreSession->start();
           $error = false;
           $data = $this->_coreSession->getMyData();
        if ($chkInsert!='TRUE') {
            $message = "successfully urlrewrites update.";
        } else {
            $message = "successfully urlrewrites import.";
        }
        return [ $data, $error, $message];
    }//urlrewritesInsert()
}
