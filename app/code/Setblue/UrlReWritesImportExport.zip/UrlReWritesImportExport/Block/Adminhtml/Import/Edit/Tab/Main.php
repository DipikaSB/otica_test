<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Edit\Tab;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Registry;

class Main extends Generic implements TabInterface
{
   /**
    * _systemStore
    *
    * @var  \Magento\Store\Model\System\Store
    */
    protected $_systemStore;
     /**
      * _groupRepository
      *
      * @var  \Magento\Customer\Api\GroupRepositoryInterface
      */
    protected $_groupRepository;
     /**
      * _searchCriteriaBuilder
      *
      * @var  \Magento\Framework\Api\SearchCriteriaBuilder
      */
    protected $_searchCriteriaBuilder;
     /**
      * _objectConverter
      *
      * @var  \Magento\Framework\Convert\DataObject
      */
    protected $_objectConverter;
     /**
      * @param \Magento\Backend\Block\Template\Context $context
      * @param \Magento\Framework\Registry $registry
      * @param \Magento\Framework\Data\FormFactory $formFactory
      * @param \Magento\Customer\Api\GroupRepositoryInterface $groupRepository
      * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
      * @param \Magento\Framework\Convert\DataObject $objectConverter
      */
    public function __construct(
        Context $context,
        Registry $registry,
        \Magento\Store\Model\System\Store $systemStore,
        FormFactory $formFactory,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Convert\DataObject $objectConverter,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_groupRepository = $groupRepository;
        $this->_searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->_objectConverter = $objectConverter;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('General');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('General');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return Generic
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('setblue_urlrewritesimportexport_data');
        $isElementDisabled = false;
         $form = $this->_formFactory->create(
             [
             'data' => [
                   'id' => 'edit_form',
                   'action' => $this->getData('action'),
                   'method' => 'post',
                   'enctype' => 'multipart/form-data'
                  ]
             ]
         );
        $form->setHtmlIdPrefix('import_');
        $fieldset = $form->addFieldset('base_fieldset', [
        'legend'    => __('General Information'),
        'class'     => 'fieldset-wide',
         ]);

        $fieldset->addField('feed_id', 'hidden', ['name' => 'feed_id']);

        $fieldset->addField(
            'entity_type_imp',
            'select',
            [
            'label' => __('Entity Type'),
            'title' => __('Entity Type'),
            'name' => 'entity_type_imp',
            'required' => false,
            'options' =>  ['0' => __('URL ReWrites')],
            'disabled' => true
            ]
        );

        $fieldset->addField(
            'file_extension',
            'select',
            [
               'label' => __('File Format'),
               'title' => __('File Format'),
               'name' => 'file_extension',
               'required' => false,
              'options' =>  ['csv' => __('CSV - Comma Separated Values ')],
               'disabled' => true,
               'style' => 'width:270px;'
               ]
        );

          $fieldset->addField(
              'import_behavior',
              'select',
              [
              'label' => __('Import Mode'),
              'title' => __('Import Mode'),
              'name' => 'import_behavior',
              'required' => true,
              'options' => $model->getImportBehavior(),
              'disabled' => $isElementDisabled,
              'style' => 'width:300px;'
              ]
          );
          $fieldset->addField(
              'progress_message',
              'select',
              [
               'label' => __('Show progress message'),
               'title' => __('Show progress message'),
               'name' => 'progress_message',
               'options' =>  $model->getYesNo(),
                'note'      => __('<strong>Note:</strong>Success and failed urlrewrites during import'),
               'disabled' => $isElementDisabled,
               'style' => 'width:100px;'
               ]
          );
        $field = $fieldset->addField(
            'fileinfo',
            'hidden',
            [
                    'name' => 'fileinfo', // to add reference later in controller.
                ]
        );
    
        $field = $fieldset->addField(
            'file',
            'text',
            [
                    'name' => 'file', // to add reference later in controller.
                    'label' => __('Upload File')
                ]
        );
        
        $renderer = $this->getLayout()
                ->createBlock('Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Renderer\UploadFile');
        $field->setRenderer($renderer);

        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '0' : '1');
        }
        $form->setValues($model->getData());
        $this->setForm($form);
        $this->_eventManager->dispatch('adminhtml_import_edit_tab_main_prepare_form', ['form' => $form]);

        return parent::_prepareForm();
    }
}
