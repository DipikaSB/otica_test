<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Import;

use Magento\Framework\UrlInterface;

/**
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
     /**
      * url Builder
      *
      * @var Magento\Framework\UrlInterface
      */
    protected $urlBuilder;

    protected $context;
    protected $messageManager;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        UrlInterface $urlBuilder,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->_coreRegistry = $registry;
        $this->context = $context;
        $this->messageManager = $messageManager;
        parent::__construct($context, $data);
    }//end __construct(

    /**
     * Initialize cms page edit block
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'feed_id';
        $this->_blockGroup = 'Setblue_UrlReWritesImportExport';
        $this->_controller = 'adminhtml_import';

        parent::_construct();

        // if ($this->_isAllowedAction('Setblue_UrlReWritesImportExport::save')) {
            $this->buttonList->update('save', 'label', __('Save'));
            $this->buttonList->add(
                'saveandcontinue',
                [
                    'label' => __('Save and Continue Edit'),
                    'class' => 'save',
                    'data_attribute' => [
                        'mage-init' => [
                            'button' => ['event' => 'saveAndContinueEdit', 'target' => '#edit_form'],
                        ],
                    ]
                ],
                -100
            );
        // } else {
        //     $this->buttonList->remove('save');
        // }

        // if ($this->_isAllowedAction('Setblue_UrlReWritesImportExport::urlrewrites_import')) {
            $this->buttonList->update('delete', 'label', __('Delete'));
        // } else {
        //     $this->buttonList->remove('delete');
        // }
    }

    /**
     * Retrieve text for header element depending on loaded page
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('setblue_urlrewritesimportexport_data')->getId()) {
            return __(
                "Edit UrlReWritesImportExport '%1'",
                $this->escapeHtml($this->_coreRegistry->registry('setblue_urlrewritesimportexport_data')->getName())
            );
        } else {
            return __('New Record');
        }
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
     /**
      * Get baseurl
      *
      * @return url
      */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }// end  getUrl()
    /**
     * Getter of url for "Save and Continue" button
     * tab_id will be replaced by desired by JS later
     *
     * @return string
     */
    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl(
            'setblue_urlrewritesimportexport/*/save',
            ['_current' => true,
            'back' => 'edit',
            'active_tab' => '{{tab_id}}'
            ]
        );
    }

    /**
     * Prepare layout
     *
     * @return \Magento\Framework\View\Element\AbstractBlock
     */
    protected function _prepareLayout()
    {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('overview') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'overview');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'overview');
                }
            };
        ";
        return parent::_prepareLayout();
    }
}
