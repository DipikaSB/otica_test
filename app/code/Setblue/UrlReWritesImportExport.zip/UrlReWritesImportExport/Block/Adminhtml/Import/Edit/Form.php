<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    protected function _construct()
    {
        parent::_construct();
        $this->setId('urlrewritesimportexport_form');
        $this->setTitle(__('General Information'));
    }// end construct
     /**
      * Prepare add review form
      *
      * @return void
      * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
      */
    protected function _prepareForm()
    {
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form',
            'action' => $this->getData('action'),
            'method' => 'post',
            'enctype' => 'multipart/form-data']]
        );
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
