<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Import\Edit\Tab;

class Blocks extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
    /**
     * Import collection
     *
     * @var \Setblue\UrlReWritesImportExport\Model\ResourceModel\Import\Collection
     */
    protected $_post;

    /**
     * Import Tab Grid Factory
     *
     * @var \Setblue\UrlReWritesImportExport\Model\ImportTabGridFactory
     */
    protected $importtabGridFactory;
    
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Cms\Model\BlockFactory $cmsBlockFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Setblue\UrlReWritesImportExport\Model\ResourceModel\Import\Collection $importFactory,
        \Setblue\UrlReWritesImportExport\Model\ImportTabGridFactory $importtabGridFactory,
        \Magento\Framework\Registry $coreRegistry,
        array $data = []
    ) {

        $this->_post = $importFactory;
        $this->importtabGridFactory = $importtabGridFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context, $backendHelper, $data);
    }

    public function _construct()
    {
        parent::_construct();
        $this->setId('urlrewritesimportexport_blocks_grid');
        $this->setDefaultSort('feed_id');
        $this->setUseAjax(true);

        if ($this->_getBlock() && $this->_getBlock()->getId()) {
            $this->setDefaultFilter(['in_blocks' => 1]);
        }

        if ($this->isReadonly()) {
            $this->setFilterVisibility(false);
        }
    }

    protected function _addColumnFilterToCollection($column)
    {
        // Set custom filter for in product flag
        if ($column->getId() == 'in_blocks') {
            $blockIds = $this->_getSelectedBlocks();
            if (empty($blockIds)) {
                $blockIds = 0;
            }

            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('feed_id', ['in' => $blockIds]);
            } else {
                if ($blockIds) {
                    $this->getCollection()->addFieldToFilter('feed_id', ['nin' => $blockIds]);
                }
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }

        return $this;
    }

    /**
     * Prepare collection
     *
     * @return Extended
     */
    protected function _prepareCollection()
    {
        $id = $this->getRequest()->getParam('feed_id');
        $tabGridcollection = $this->importtabGridFactory->create()->getCollection()
            ->addExportIdFilter($id);
        $this->setCollection($tabGridcollection);
        return parent::_prepareCollection();
    }

    protected function _getBlock()
    {
        return $this->_coreRegistry->registry('current_urlrewritesimportexport_block');
    }

    public function isReadonly()
    {
        return 0;
    }

    protected function _prepareColumns()
    {
        if (!$this->isReadonly()) {
            $this->addColumn(
                'in_blocks',
                [
                'type' => 'checkbox',
                'name' => 'in_blocks',
                'values' => $this->_getSelectedBlocks(),
                'align' => 'center',
                'index' => 'feed_id',
                'header_css_class' => 'col-select',
                'column_css_class' => 'col-select'
                    ]
            );
        }

        $this->addColumn(
            'import_grid_id',
            [
            'header' => __('ID'),
            'sortable' => true,
            'index' => 'import_grid_id',
            'header_css_class' => 'col-id',
            'column_css_class' => 'col-id'
                ]
        );

        $this->addColumn(
            'file',
            [
            'header' => __('File'),
            'index' => 'file',
            'header_css_class' => 'col-name',
            'column_css_class' => 'col-name'
            ]
        );
         $this->addColumn(
             'admin',
             [
             'header' => __('Admin Name'),
             'index' => 'admin',
             'header_css_class' => 'col-name',
             'column_css_class' => 'col-name'
             ]
         );
         $this->addColumn(
             'updated_at',
             [
             'header' => __('Imported at'),
             'index' => 'updated_at',
             'header_css_class' => 'col-name',
             'column_css_class' => 'col-name'
             ]
         );

        return parent::_prepareColumns();
    }

    public function getGridUrl()
    {
        return $this->getData('grid_url') ?
                $this->getData('grid_url') :
            $this->getUrl('*/import/blocks', ['_current' => true]);
    }

    public function _getSelectedBlocks()
    {
        
        return $blocksArr[] = ['position' => '0'];
    }

    public function getRelatedBlocks()
    {
        $id = $this->getRequest()->getParam('feed_id');
        $blocksArr = [];
        foreach ($this->_coreRegistry->registry('current_urlrewritesimportexport_blocks_import')->getRelatedBlocks($id) as $blocks) {
            $blocksArr[''] = ['position' => '0'];
        }
        return $blocksArr;
    }
}
