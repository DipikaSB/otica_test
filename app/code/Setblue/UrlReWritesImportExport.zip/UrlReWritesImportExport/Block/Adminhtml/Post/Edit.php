<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post;

use Magento\Framework\UrlInterface;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
     /**
      * url Builder
      *
      * @var Magento\Framework\UrlInterface
      */
    protected $urlBuilder;
     /**
      * @param \Magento\Backend\Block\Widget\Context $context
      * @param \Magento\Framework\Registry  $registry
      * @param Magento\Framework\UrlInterface $urlBuilder
      * @param array  $data
      */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        UrlInterface $urlBuilder,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->_coreRegistry = $registry;
        $this->context = $context;
        $this->messageManager = $messageManager;
        parent::__construct($context, $data);
    }//end __construct()

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'export_id';
        $this->_blockGroup = 'Setblue_UrlReWritesImportExport';
        $this->_controller = 'adminhtml_post';
        parent::_construct();
        
        if ($this->_isAllowedAction('Setblue_UrlReWritesImportExport::urlrewrites_export')) {
            $this->buttonList->update('save', 'label', __('Save'));
            $this->buttonList->add(
                'saveandcontinue',
                [
                    'label' => __('Save and Continue Edit'),
                    'class' => 'save',
                    'data_attribute' => [
                        'mage-init' => [
                            'button' => ['event' => 'saveAndContinueEdit', 'target' => '#edit_form'],
                        ],
                    ]
                ],
                -100
            );
        } else {
            $this->buttonList->remove('save');
        }

        if ($this->_isAllowedAction('Setblue_UrlReWritesImportExport::urlrewrites_export')) {
            $this->buttonList->update('delete', 'label', __('Delete'));
        } else {
            $this->buttonList->remove('delete');
        }
    }//end __construct()
    /**
     * @return String
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('setblue_urlrewritesimportexport_data')->getId()) {
            return __(
                "Edit UrlReWritesImportExport '%1'",
                $this->escapeHtml($this->_coreRegistry->registry('setblue_urlrewritesimportexport_data')->getName())
            );
        } else {
            return __('New Record');
        }
    }// end  getHeaderText()
     /**
      * permission method in admin controller
      *
      * @return bolean
      */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }// end  _isAllowedAction()
     /**
      * Get url of generate controller
      *
      * @return url
      */
    public function getGenerateCsvUrl()
    {
             return $this->getUrl('setblue_urlrewritesimportexport/post/generate', ['export_id' => $this->getRequest()->getParam('export_id')]);
    }// end  getGenerateXmlUrl()
     /**
      * Get baseurl
      *
      * @return url
      */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }// end  getUrl()
     /**
      * Prepare the layout.
      *
      * @return $this
      */
    protected function _prepareLayout()
    {
        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('overview') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'overview');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'overview');
                }
            };
        ";
        return parent::_prepareLayout();
    }
}
