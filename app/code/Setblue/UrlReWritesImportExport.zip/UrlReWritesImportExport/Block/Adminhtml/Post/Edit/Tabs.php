<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Edit;

/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected $_coreRegistry;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Framework\Registry $coreRegistry,
        array $data = []
    ) {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context, $jsonEncoder, $authSession, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('post_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('URL ReWrites Export Information'));
    }

    protected function _beforeToHtml()
    {

        $model = $this->_coreRegistry->registry('setblue_urlrewritesimportexport_data');
        $this->addTab(
            'related_blocks',
            [
            'label' => __('Run History'),
            'url' => $this->getUrl('*/*/blocks', ['_current' => true]),
            'class' => 'ajax',
            ]
        );

        parent::_beforeToHtml();
    }
}
