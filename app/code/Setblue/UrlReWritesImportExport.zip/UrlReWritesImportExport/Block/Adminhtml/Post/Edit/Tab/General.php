<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Edit\Tab;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Registry;

class General extends Generic implements TabInterface
{

     /**
      * _systemStore
      *
      * @var  \Magento\Store\Model\System\Store
      */
    protected $_systemStore;
    /**
     * _groupRepository
     *
     * @var  \Magento\Customer\Api\GroupRepositoryInterface
     */
    protected $_groupRepository;
    /**
     * _searchCriteriaBuilder
     *
     * @var   \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteriaBuilder;
    /**
     * _objectConverter
     *
     * @var  \Magento\Framework\Convert\DataObject
     */
    protected $_objectConverter;

    public function __construct(
        Context $context,
        Registry $registry,
        \Magento\Store\Model\System\Store $systemStore,
        FormFactory $formFactory,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Convert\DataObject $objectConverter,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_groupRepository = $groupRepository;
        $this->_searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->_objectConverter = $objectConverter;
        parent::__construct($context, $registry, $formFactory, $data);
    }//end __construct()

     /**
      * Get Tab Label
      *
      * @return string
      */
    public function getTabLabel()
    {
        return __('General');
    }//end getTabLabel()

     /**
      * Get Tab Tittle
      *
      * @return string
      */
    public function getTabTitle()
    {
        return __('General');
    }//end getTabLabel()

    /**
     * Returns status flag about this tab can be shown or not
     *
     * @return true
     */

    public function canShowTab()
    {
        return true;
    }//end canShowTab()

    /**
     * Returns status flag about this tab hidden or not
     *
     * @return true
     */
    public function isHidden()
    {
        return false;
    }//end isHidden(

    /**
     * Prepare form before rendering HTML
     *
     * @return Generic
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('setblue_urlrewritesimportexport_data');
        $isElementDisabled = false;
         $form = $this->_formFactory->create(
             [
             'data' => [
                   'id' => 'edit_form',
                   'action' => $this->getData('action'),
                   'method' => 'post',
                   'enctype' => 'multipart/form-data'
                  ]
             ]
         );
        $form->setHtmlIdPrefix('post_');
        $fieldset = $form->addFieldset('base_fieldset', [
        'legend'    => __('Profile Information'),
        'class'     => 'fieldset-wide',
         ]);

        if ($model->getExportId()) {
            $fieldset->addField('export_id', 'hidden', ['name' => 'export_id']);
        }
        
          $fieldset->addField(
              'url_rewrite',
              'select',
              [
               'label' => __('Entity Type'),
               'title' => __('Entity Type'),
               'name' => 'url_rewrite',
               'required' => false,
               'options' =>  ['0' => __('Url Rewrite')],
               'disabled' => true,
               'style' => 'width:270px;'
               ]
          );

         $fieldset->addField(
             'file_type',
             'select',
             [
               'label' => __('File Format'),
               'title' => __('File Format'),
               'name' => 'file_type',
               'required' => false,
               'options' =>  ['CSV' => __('CSV - Comma Separated Values ')],
               'disabled' => true,
               'style' => 'width:270px;'
               ]
         );

          $fieldset->addField(
              'file_name',
              'text',
              [
              'name' => 'file_name',
              'label' => __('File Name'),
              'title' => __('File Name'),
              'required' => true,
              'note'      => __('Only file name required with no extension.</br><strong> NOTE:</strong> Please dont use <strong> "_" </strong> in the file name <br> <strong> example:</strong>
                urlrewrites_information'),
              'disabled' => $isElementDisabled
              ]
          );
          $fieldset->addField(
              'url_key',
              'text',
              [
              'name' => 'url_key',
              'label' => __('File URL'),
              'title' => __('File URL'),
              'required' => true,
              'note'      => __('<strong>example:</strong> "/urlrewritesimportexport/"<strong> or </strong> "/" for base path (path must be writeable)'),
              'disabled' => $isElementDisabled
              ]
          );

          $fieldset1 = $form->addFieldset(
              'base_fieldset1',
              ['legend' => __('Entity Attributes')]
          );

          $fieldset1->addField(
              'export_by',
              'select',
              [
               'label' => __('Export By'),
               'title' => __('Export By'),
               'name' => 'export_by',
               'required' => false,
               'options' =>  ['0' => __('All'), '1' => __('Entity Type'), '2' => __('Store View'), '3' => __('Redirect Type')],
               'disabled' => false
               ]
          );
          $fieldset1->addField(
              'entity_type',
              'select',
              [
               'label' => __('Choose Entity Type'),
               'title' => __('Choose Entity Type'),
               'name' => 'entity_type',
               'required' => false,
               'options' =>  ['all' => __('All'), 'category' => __('Category'), 'cms-page' => __('CMS Page'), 'product' => __('Product'), 'custom' => __('Custom')],
               'disabled' => false
               ]
          );
          $fieldset1->addField(
              'redirect_type',
              'select',
              [
               'label' => __('Choose Redirect Type'),
               'title' => __('Choose Redirect Type'),
               'name' => 'redirect_type',
               'required' => false,
               'options' =>  ['all' => __('All'), '0' => __('No'), '301' => __('Yes(301 Moved Permanently)'), '302' => __('Yes(302 Found)')],
               'disabled' => false
               ]
          );
        if (!$this->_storeManager->isSingleStoreMode()) {
            $field = $fieldset1->addField(
                'store_id',
                'select',
                [
                'name' => 'store_id',
                'label' => __('Store View'),
                'title' => __('Store View'),
                'required' => false,
                'values' => $this->_systemStore->getStoreValuesForForm(false, true),
                'disabled' => $isElementDisabled
                ]
            );
            $renderer = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element'
            );
            $field->setRenderer($renderer);
        } else {
            $fieldset->addField(
                'store_id',
                'hidden',
                [
                'name' => 'store_id',
                'value' => $this->_storeManager->getStore(true)->getId()
                ]
            );
            $model->setStoreIds($this->_storeManager->getStore(true)->getId());
        }
          $field1 = $fieldset1->addField(
              'export_btn',
              'text',
              [
                    'name' => 'export_btn', // to add reference later in controller.
                    'label' => __('Export File')
                ]
          );
        
        $renderer = $this->getLayout()
                ->createBlock('Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Renderer\ExportFile');
        $field1->setRenderer($renderer);

        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '0' : '1');
        }
        $form->setValues($model->getData());

          $this->setChild(
            'form_after',
            $this->getLayout()->createBlock(
                'Magento\Backend\Block\Widget\Form\Element\Dependence'
            )
            ->addFieldMap(
                "post_export_by",
                'export_by'
            )->addFieldMap(
                "post_entity_type",
                'entity_type'
            )->addFieldMap(
                "post_redirect_type",
                'redirect_type'
            )->addFieldMap(
                "post_store_id",
                'store_id'
            )->addFieldDependence(
                'entity_type',
                'export_by',
                '1'
            )->addFieldDependence(
                'store_id',
                'export_by',
                '2'
            )->addFieldDependence(
                'redirect_type',
                'export_by',
                '3'
            )
        );
        $this->setForm($form);
        $this->_eventManager->dispatch('adminhtml_post_edit_tab_main_prepare_form', ['form' => $form]);

        return parent::_prepareForm();
    }
}
