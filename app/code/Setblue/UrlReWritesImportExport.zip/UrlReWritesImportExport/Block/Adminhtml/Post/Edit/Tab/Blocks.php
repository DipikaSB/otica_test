<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Edit\Tab;

class Blocks extends \Magento\Backend\Block\Widget\Grid\Extended
{
/**
 * Core registry
 *
 * @var \Magento\Framework\Registry
 */
    protected $_coreRegistry = null;
   /**
    *  post
    *
    * @var \Setblue\UrlReWritesImportExport\Model\ResourceModel\Post\Collection
    */

    protected $_post;
    /**
     * tabGridFactory
     *
     * @var Setblue\UrlReWritesImportExport\Model\TabGridFactory
     */
    protected $tabGridFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Cms\Model\BlockFactory $cmsBlockFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Setblue\UrlReWritesImportExport\Model\ResourceModel\Post\Collection $postFactory,
        \Setblue\UrlReWritesImportExport\Model\TabGridFactory $tabGridFactory,
        \Magento\Framework\Registry $coreRegistry,
        array $data = []
    ) {

        $this->_post = $postFactory;
        $this->tabGridFactory = $tabGridFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context, $backendHelper, $data);
    }

    public function _construct()
    {
        parent::_construct();

        $this->setId('urlrewritesimportexport_blocks_grid');
        $this->setDefaultSort('export_id');
        $this->setUseAjax(true);

        if ($this->_getBlock() && $this->_getBlock()->getId()) {
            $this->setDefaultFilter(['in_blocks' => 1]);
        }

        if ($this->isReadonly()) {
            $this->setFilterVisibility(false);
        }
    }

    protected function _addColumnFilterToCollection($column)
    {
        // Set custom filter for in product flag
        if ($column->getId() == 'in_blocks') {
            $blockIds = $this->_getSelectedBlocks();
            if (empty($blockIds)) {
                $blockIds = 0;
            }

            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('export_id', ['in' => $blockIds]);
            } else {
                if ($blockIds) {
                    $this->getCollection()->addFieldToFilter('export_id', ['nin' => $blockIds]);
                }
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }

        return $this;
    }

    /**
     * Prepare collection
     *
     * @return Extended
     */
    protected function _prepareCollection()
    {
        $id = $this->getRequest()->getParam('export_id');
        $tabGridcollection = $this->tabGridFactory->create()->getCollection()
            ->addExportIdFilter($id);
        $this->setCollection($tabGridcollection);
        return parent::_prepareCollection();
    }

    protected function _getBlock()
    {
        return $this->_coreRegistry->registry('current_urlrewritesimportexport_block');
    }

    public function isReadonly()
    {
        return 0;
    }

    protected function _prepareColumns()
    {
        if (!$this->isReadonly()) {
            $this->addColumn(
                'in_blocks',
                [
                'type' => 'checkbox',
                'name' => 'in_blocks',
                'values' => $this->_getSelectedBlocks(),
                'align' => 'center',
                'index' => 'export_id',
                'header_css_class' => 'col-select',
                'column_css_class' => 'col-select'
                    ]
            );
        }

        $this->addColumn(
            'updated_at',
            [
            'header' => __('Run At'),
            'sortable' => true,
            'index' => 'updated_at',
            'header_css_class' => 'col-id',
            'column_css_class' => 'col-id'
                ]
        );

        $this->addColumn(
            'file_size',
            [
            'header' => __('File Size'),
            'index' => 'file_size',
            'header_css_class' => 'col-name',
            'column_css_class' => 'col-name'
            ]
        );

        $this->addColumn('action', [
            'header' => __('Exported File'),
            'width' => '100',
            'type' => 'action',
            'getter' => 'getId',
            'renderer' => 'Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Renderer\Link',
            'actions' => [
                [
                    'caption' => __('Edit'),
                    'url' => ['base' => 'Setblue_UrlReWritesImportExport/Post/edit'],
                    'field' => 'id'
                ]
            ],
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
        ]);
        $this->addColumn('archive', [
            'header' => __('Exported Archive'),
            'width' => '100',
            'type' => 'archive',
            'getter' => 'getId',
            'renderer' => 'Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Renderer\LinkArchive',
            'actions' => [
                [
                    'caption' => __('Edit'),
                    'url' => ['base' => 'Setblue_UrlReWritesImportExport/Post/edit'],
                    'field' => 'id'
                ]
            ],
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
        ]);

        return parent::_prepareColumns();
    }

    public function getGridUrl()
    {
        return $this->getData('grid_url') ?
                $this->getData('grid_url') :
            $this->getUrl('*/*/blocks', ['_current' => true]);
    }

    public function _getSelectedBlocks()
    {
        return $blocksArr[] = ['position' => '0'];
    }

    public function getRelatedBlocks()
    {
        $id = $this->getRequest()->getParam('export_id');
        $blocksArr = [];
        foreach ($this->_coreRegistry->registry('current_urlrewritesimportexport_blocks')->getRelatedBlocks($id) as $blocks) {
            $blocksArr[''] = ['position' => '0'];
        }
        return $blocksArr;
    }
}
