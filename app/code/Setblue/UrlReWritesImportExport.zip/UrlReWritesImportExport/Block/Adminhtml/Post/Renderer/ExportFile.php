<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Renderer;

class ExportFile extends \Magento\Backend\Block\Widget\Form\Renderer\Fieldset\Element implements
    \Magento\Framework\Data\Form\Element\Renderer\RendererInterface
{
    /**
     * @var string
     */
    protected $_template = 'Setblue_UrlReWritesImportExport::exportfile.phtml';
     /**
      * Core registry
      *
      * @var \Magento\Framework\Registry
      */
    protected $_coreRegistry;
     /**
      * @param \Magento\Backend\Block\Template\Context $context
      * @param \Magento\Framework\Registry                      $registry
      */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Edit $url,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->url = $url;
        parent::__construct($context, $data);
    }//end __construct()
   /**
    *
    * @return string
    */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->_element = $element;
        $html = $this->toHtml();
        return $html;
    }//end render()
   /**
    * Get URL
    * @return link
    */
    public function getExportUrl()
    {
        return $this->url->getGenerateCsvUrl();
    }
}
