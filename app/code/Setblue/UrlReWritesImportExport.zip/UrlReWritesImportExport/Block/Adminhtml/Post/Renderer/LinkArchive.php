<?php

namespace Setblue\UrlReWritesImportExport\Block\Adminhtml\Post\Renderer;

use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

class LinkArchive extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
    /**
     * url Builder
     *
     * @var Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\UrlInterface  $urlBuilder
     * @param \Magento\Framework\App\Filesystem\DirectoryList $directoryList
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Context $context,
        UrlInterface $urlBuilder,
        StoreManagerInterface $storeManager,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList,
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->directoryList = $directoryList;
        $this->_storeManager = $storeManager;
        parent::__construct($context, $data);
    }//end __construct()

    public function render(\Magento\Framework\DataObject $row)
    {
        $id =  $row->getData('export_id');
        $filename =  $row->getData('filename');
        $filetype =  $row->getData('filetype');
        $dir = $row->getData('url_path');
        $directory = ltrim($dir, '/');
        $storeManager = $this->_storeManager;
        $currentStore = $storeManager->getStore();

        $url = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA). $directory . $filename.'.zip';

        $checkfile = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)
                . $dir.$filename.'.zip';
        if (!file_exists($checkfile)) {
            return '<p>'.$filename.'.zip</p>';
        } else {
            $filename = str_replace(" ", "_", $filename);
            return  '<a id="url" href="'.$url.'" target="_blank">'.$filename.'.zip</a>';
        }
    }
}
