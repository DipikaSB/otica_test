<?php

namespace Setblue\UrlReWritesImportExport\Model;

class TabGrid extends \Magento\Framework\Model\AbstractModel implements
    \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'setblue_urlrewritesimportexport_tab_grid_data';
    /**
     * Cache Tag
     *
     * @var string
     */
    protected $_cacheTag = 'setblue_urlrewritesimportexport_tab_grid_data';
     /**
      * Event prefix
      *
      * @var string
      */
    protected $_eventPrefix = 'setblue_urlrewritesimportexport_tab_grid_data';
    /**
     * Init collection and determine table names
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Setblue\UrlReWritesImportExport\Model\ResourceModel\TabGrid');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
