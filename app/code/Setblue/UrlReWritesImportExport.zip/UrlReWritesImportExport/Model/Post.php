<?php

namespace Setblue\UrlReWritesImportExport\Model;

class Post extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var int
     */
    const NO = 0;
    /**
     * @var int
     */
    const  YES = 1;
    
    const CACHE_TAG = 'setblue_urlrewritesimportexport_export';
    /**
     * Cache Tag
     *
     * @var string
     */
    protected $_cacheTag = 'setblue_urlrewritesimportexport_export';
    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'setblue_urlrewritesimportexport_export';

     /**
      * @param \Magento\Framework\Model\Context $context
      * @param \Magento\Framework\Registry  $registry
      * @param \Magento\Framework\Data\FormFactory $formFactory
      * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
      * @param \Setblue\UrlReWritesImportExport\Model\Post\Condition\CombineFactory $combineFactory
      * @param \Magento\CatalogRule\Model\Rule\Action\CollectionFactory $actionCollectionFactoryr
      * @param \Magento\CatalogRule\Helper\Data $catalogRuleData
      * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
      * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
      */

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }// end construct
    /**
     * Init collection and determine table names
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Setblue\UrlReWritesImportExport\Model\ResourceModel\Post');
    }// end construct

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }// end getIdentities

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }// end getDefaultValues
    /**
     * @return array
     *
     */
    public function getYesNo()
    {
        return [self::NO => __('No'), self::YES => __('Yes')];
    }// end getYesNo
}//end class
