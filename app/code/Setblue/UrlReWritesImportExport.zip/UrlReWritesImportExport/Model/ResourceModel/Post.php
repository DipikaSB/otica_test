<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\Context;

class Post extends \Magento\Rule\Model\ResourceModel\AbstractResource
{
    /**
     * @var string
     */
    protected $_store = null;
    protected $resource;
    /**
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Framework\App\ResourceConnection $resource
     */
    public function __construct(
        Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        $connectionName = null
    ) {
        parent::__construct($context, $connectionName);
        $this->resource = $resource;
    }

    protected function _construct()
    {
        $this->_init('setblue_urlrewritesimportexport_export', 'export_id');
    }//end construct
    public function TableInfo()
    {
        $salesUrlReWrites = $this->resource->getTableName("url_rewrite");
        $fields = $this->getConnection()->describeTable($this->getTable($salesUrlReWrites));
        $AllFields='';
        foreach ($fields as $key => $val) {
            if ($val['COLUMN_NAME']!='url_rewrite_id') {
                 $AllFields .= $val['COLUMN_NAME'] .',';
            }
        }
        $AllFields = rtrim($AllFields, ',');
        return $AllFields;
    }

    public function getAllFieldsData($data)
    {
        $resource = $this->resource;
        $connection = $resource->getConnection();
        $salesUrlReWrites = $this->resource->getTableName("url_rewrite");
        $fields = $this->getConnection()->describeTable($this->getTable($salesUrlReWrites));
        $sql='';
        $sql .= "Select ".$this->TableInfo();
        $sql .= " FROM  ". $salesUrlReWrites;

        if ($data['export_by']==1) {
            if ($data['entity_type']!='all' && $data['entity_type']!='custom') {
                $sql .= " WHERE (`entity_type` IN ('".$data['entity_type']."')) ";
            } elseif ($data['entity_type']=='custom') {
                $custom=["product","category","cms-page"];
                $custom1 = join("','", $custom);
                $sql .= " WHERE (`entity_type` NOT IN ('".$custom1."')) ";
            } else {
            }
        }
        if ($data['export_by']==2) {
            if ($data['store_id']!=0) {
                $sql .= " WHERE (`store_id`=".$data['store_id'].")";
            }
        }
        if ($data['export_by']==3) {
            if ($data['redirect_type']!='all') {
                $sql .= " WHERE (`redirect_type`=".$data['redirect_type'].")";
            }
        }
        return $connection->fetchAll($sql); // gives associated array, table fields as key in array.
    }
}
