<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel;

use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\Stdlib\DateTime;
use \Magento\Framework\Model\ResourceModel\Db\Context;

class Import extends \Magento\Rule\Model\ResourceModel\AbstractResource
{

    /**
     * Store model
     *
     * @var null|\Magento\Store\Model\Store
     */
    protected $_store = null;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    protected $_coreSession;
    protected $resource;
    /**
     * @var \Magento\Framework\Stdlib\DateTime
     */
    protected $dateTime;

    /**
     * Store associated with Import entities information map
     *
     * @var array
     */

    /**
     * Construct
     *
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime $dateTime
     * @param string $connectionName
     ResourceModel*/
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        DateTime $dateTime,
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Framework\App\ResourceConnection $resource,
        $connectionName = null
    ) {

        parent::__construct($context, $connectionName);
        $this->_storeManager = $storeManager;
        $this->dateTime = $dateTime;
        $this->_coreSession = $coreSession;
        $this->resource = $resource;
    }

    protected function _construct()
    {
        $this->_init('setblue_urlrewritesimportexport_import', 'feed_id');
    }
    /**
     * Delete UrlReWrites
     *
     * @return Null
     */
    public function DeleteUrlReWrites($request_path, $storeId)
    {    
        $connection  = $this->resource->getConnection();
         $where = ["request_path = ?" => $request_path,"store_id = ?" => $storeId];
        $connection->delete($this->resource->getTableName("url_rewrite"), $where);
        return;
    }//end DeleteUrlReWrites()
       /**
        * Check urlrewrite Exist
        *
        * @return Array
        */
    public function CheckUrlReWriteExist($request_path, $storeId)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("url_rewrite"), 'url_rewrite_id')->where("request_path = ?", $request_path)
                 ->where("store_id = ?", $storeId);
        $rewriteId = $connection->fetchone($sql);
        return $rewriteId;
    }//end CheckUrlReWriteExist()
    /**
     * Check urlrewrite Exist
     *
     * @return Array
     */
    public function NewUrlReWriteTYpeExist($new_request_path, $storeId)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("url_rewrite"), 'url_rewrite_id')->where("request_path = ?", $new_request_path)
                 ->where("store_id = ?", $storeId);
        $rewriteId = $connection->fetchone($sql);
        return $rewriteId;
    }//end NewUrlReWriteTYpeExist()
    /**
     * Check category id Exist
     *
     * @return Array
     */
    public function categoryIdExist($catId)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("catalog_category_entity"), 'entity_id')->where("entity_id = ?", $catId);
        $cat_id = $connection->fetchone($sql);
        return $cat_id;
    }//end categoryIdExist()
    /**
     * Check product id Exist
     *
     * @return Array
     */
    public function productIdExist($prdId)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("catalog_product_entity"), 'entity_id')->where("entity_id = ?", $prdId);
        $pro_id = $connection->fetchone($sql);
        return $pro_id;
    }//end productIdExist()
     /**
      * Check urlreWrite id Exist
      *
      * @return Array
      */
    public function urlrewriteIdExist($urlrewriteId)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("url_rewrite"), 'request_path')->where("url_rewrite_id = ?", $urlrewriteId);
        $urlrewrite_id = $connection->fetchone($sql);
        return $urlrewrite_id;
    }//end urlrewriteIdExist()
     /**
      * Check urlrewrite Exist
      *
      * @return Array
      */
    public function cmsPageIdExist($id)
    {
        $connection  = $this->resource->getConnection();
        $sql = $connection->select()
            ->from($this->resource->getTableName("cms_page"), 'page_id')->where("page_id = ?", $id);
        $cms_pageId = $connection->fetchone($sql);
        return $cms_pageId;
    }//end CheckUrlReWriteExist()
     /**
      * Update UrlReWrites Data
      *
      * @return Array
      */
    public function UpdateUrlReWritesData($urlrewriteData, $newRequestPath)
    {
        try {
            // $urlrewriteData['store_id']
            if (isset($urlrewriteData['url_rewrite_id'])) {
                $checkurl = $this->urlrewriteIdExist($urlrewriteData['url_rewrite_id']);
                if (!empty($checkurl)) {
                    if ($checkurl != $urlrewriteData['request_path']) {
                        unset($urlrewriteData['url_rewrite_id']);
                    }
                }
            }
             $urlrewriteData['is_autogenerated'] = 0;
             $connection  = $this->resource->getConnection();
             $where = ["request_path = ?" => $urlrewriteData['request_path'],"store_id = ?" => $urlrewriteData['store_id']];
             $connection->update($this->resource->getTableName("url_rewrite"), $urlrewriteData, $where);
             $data = ["request_path"=> $newRequestPath];
            if (!empty($newRequestPath)) {
                $connection->update($this->resource->getTableName("url_rewrite"), $data, $where);
            }
        } catch (\Exception $e) {
            $data = $this->_coreSession->getMyData();
            $ErrorChek = $e->getMessage();
            $message= '';
            return [ $data, $ErrorChek, $message];
        }
        return;
    }//end UpdateUrlReWritesData()
    /**
     * Insert UrlReWrites Data
     *
     * @return Array
     */
    public function InsertUrlReWritesData($urlrewriteData)
    {
        try {
            if (isset($urlrewriteData['url_rewrite_id'])) {
                $checkurl = $this->urlrewriteIdExist($urlrewriteData['url_rewrite_id']);
                if (!empty($checkurl)) {
                    unset($urlrewriteData['url_rewrite_id']);
                }
            }
            $urlrewriteData['is_autogenerated'] = 0;
            $this->resource->getConnection()->insertMultiple($this->resource->getTableName("url_rewrite"), $urlrewriteData);
        } catch (\Exception $e) {
            $data = $this->_coreSession->getMyData();
            $ErrorChek = $e->getMessage();
            $message= '';
            return [ $data, $ErrorChek, $message];
        }
        return;
    }//end InsertUrlReWritesData()
}
