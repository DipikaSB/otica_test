<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel\Import;

//use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends \Magento\Rule\Model\ResourceModel\Rule\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'feed_id';
    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    ) {
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
        $this->_storeManager = $storeManager;
    }

    protected function _construct()
    {
        $this->_init(
            'Setblue\UrlReWritesImportExport\Model\Import',
            'Setblue\UrlReWritesImportExport\Model\ResourceModel\Import'
        );
    }
    /**
     * Add Id
     *
     * @param array csv heading data
     * @return $this
     */
    public function addOnlyMappingFilter($ImportProfileid)
    {
        $this->getSelect()
                        ->where("feed_id = " . $ImportProfileid);
        return $this;
    }
}
