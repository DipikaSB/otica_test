<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel\Post;

class Collection extends \Magento\Rule\Model\ResourceModel\Rule\Collection\AbstractCollection
{

    /**
     *
     * @var int
     */
    protected $_idFieldName = 'export_id';
     /**
      * Store Manager
      *
      * @var \Magento\Store\Model\StoreManagerInterface
      */
    protected $_storeManager;
   
    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    ) {
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
        $this->_storeManager = $storeManager;
    }

    protected function _construct()
    {
        $this->_init(
            'Setblue\UrlReWritesImportExport\Model\Post',
            'Setblue\UrlReWritesImportExport\Model\ResourceModel\Post'
        );
    }
    public function addExportIdFilter($id)
    {
        $this->getSelect()
              ->where('main_table.export_id = ' . $id);
        return $this;
    }
}
