<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel\ImportTabGrid;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

     /**
      * id
      *
      * @var int
      */
    protected $_idFieldName = 'import_grid_id';
     /**
      * Event prefix
      *
      * @var string
      */
    protected $_eventPrefix = 'setblue_urlrewritesimportexport_import_tab_grid_data';

    /**
     * Event object name
     *
     * @var string
     */
    protected $_eventObject = 'import_tab_grid_collection';
    /**
     * Init collection and determine table names
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Setblue\UrlReWritesImportExport\Model\ImportTabGrid',
            'Setblue\UrlReWritesImportExport\Model\ResourceModel\ImportTabGrid'
        );
    }

    public function addExportIdFilter($id)
    {
        $this->getSelect()
              ->where('main_table.feed_id = ' . $id);
        return $this;
    }
}
