<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel;

class ImportTabGrid extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
   /**
    * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
    */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context
    ) {
        parent::__construct($context);
    }//end construct

    /**
     * Init collection and determine table name
     *
     * @return void
     */

    protected function _construct()
    {
        $this->_init('setblue_urlrewritesimportexport_import_tab_grid_data', 'import_grid_id');
    }//end __construct
}//end class
