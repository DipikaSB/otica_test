<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel\TabGrid;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

     /**
      * id
      *
      * @var int
      */
    protected $_idFieldName = 'grid_id';
     /**
      * Event prefix
      *
      * @var string
      */
    protected $_eventPrefix = 'setblue_urlrewritesimportexport_tab_grid_data';

    /**
     * Event object name
     *
     * @var string
     */
    protected $_eventObject = 'tab_grid_collection';
    /**
     * Init collection and determine table names
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Setblue\UrlReWritesImportExport\Model\TabGrid',
            'Setblue\UrlReWritesImportExport\Model\ResourceModel\TabGrid'
        );
    }

    public function addExportIdFilter($id)
    {
        $this->getSelect()
              ->where('main_table.export_id = ' . $id);
        return $this;
    }
}
