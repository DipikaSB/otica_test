<?php

namespace Setblue\UrlReWritesImportExport\Model\ResourceModel;

class TabGrid extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
   /**
    * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
    */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context
    ) {
        parent::__construct($context);
    }//end construct

    /**
     * Init collection and determine table name
     *
     * @return void
     */

    protected function _construct()
    {
        $this->_init('setblue_urlrewritesimportexport_tab_grid_data', 'grid_id');
    }//end __construct
}//end class
