<?php

namespace Setblue\UrlReWritesImportExport\Model;

class Import extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'setblue_urlrewritesimportexport_import';
     /**
      * Cache Tag
      *
      * @var string
      */
    protected $_cacheTag = 'setblue_urlrewritesimportexport_import';
      /**
       * Event prefix
       *
       * @var string
       */
    protected $_eventPrefix = 'setblue_urlrewritesimportexport_import';
     /**
      * Init collection and determine table names
      *
      * @return void
      */
    protected function _construct()
    {
        $this->_init('Setblue\UrlReWritesImportExport\Model\ResourceModel\Import');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
    public function getImportBehavior()
    {
        return ['0' => __('Add/Merge Existing Data'), '1' => __('Add/Replace Existing Data'), '2' => __('Delete')];
    }
    /**
     * @return array
     *
     */
    public function getYesNo()
    {
        return ['0' => __('No'), '1' => __('Yes')];
    }// end getYesNo
}
